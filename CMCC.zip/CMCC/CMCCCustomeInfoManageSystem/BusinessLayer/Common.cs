﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Linq;
using DataAccessLayer;
using BusinessLayer;
using Newtonsoft.Json;
using System.Configuration;

namespace BusinessLayer
{
    public class Common
    {
        CMCCDBDataContext CMCC = new CMCCDBDataContext();
        public bool UserLoginCheck(string UserID,string PassWord,string UserRole)
        {
            try
            {
                var Login = CMCC.UserLogin.Where(p => p.UserID == UserID && p.PassWord == PassWord && p.UserRole == UserRole).Count() == 1 ? true : false;
                return Login;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public bool SetLoginUser(string UserID,string UserRole)
        {
            try
            {
                Configuration cfa = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                cfa.AppSettings.Settings["LoginUser"].Value = UserID;
                cfa.AppSettings.Settings["LoginRole"].Value = UserID;
                cfa.Save();
                ConfigurationManager.RefreshSection("appSettings");
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public string GetLoginUser()
        {
            string LoginUser = ConfigurationManager.AppSettings["LoginUser"];
            return LoginUser;
        }
        public string GetLoginRole()
        {
            string LoginRole = ConfigurationManager.AppSettings["LoginRole"];
            return LoginRole;
        }
        public bool CheckUserID(string UserID)
        {
            using(CMCC)
            {
                try{
                    var checkresult = CMCC.UserLogin.Where(p => p.UserID == UserID).Count() == 0 ? true : false;
                    return checkresult;
                }
                catch(Exception e)
                {
                    return false;
                }
            }
        }
        public bool AddUser(string UserID, string UserRole, string UserName, int UserSex, DateTime Birthday, string PhoneNum, string Email, string Password)
        {
            if (!String.IsNullOrEmpty(UserID) && !String.IsNullOrEmpty(Password))
            {
                using (CMCCDBDataContext Cm = new CMCCDBDataContext())
                {
                    try
                    {
                        var UL = new UserLogin
                        {
                        ID = Guid.NewGuid(),
                        UserID = UserID,
                        PassWord = Password,
                        CreateTime = System.DateTime.Now,
                        UpdateTime = System.DateTime.Now,
                        UserRole = UserRole,
                        };
                        Cm.UserLogin.InsertOnSubmit(UL);
                        Cm.SubmitChanges();                   
                        var UI = new UserInfo { 
                        ID = Guid.NewGuid(),
                        UserID = UserID,
                        UserName = UserName,
                        Sex = UserSex,
                        Birthday = Birthday,
                        PhoneNum = PhoneNum,
                        Email = Email,
                        };
                        Cm.UserInfo.InsertOnSubmit(UI);
                        Cm.SubmitChanges();
                        return true;
                    }
                    catch (Exception e)
                    {
                        return false;
                    }
                }
            }
            else
            {
                return false;
            }
        }
        public  string[] GetUserInfo(string UserID)
        {
            if (!String.IsNullOrEmpty(UserID))
            {
                    try
                    {
                       var  UserInfo = CMCC.UserInfo.Single(p => p.UserID == UserID);
                        string[] User = {UserInfo.UserID,UserInfo.UserName,UserInfo.Sex.ToString(),UserInfo.Birthday.ToString(),UserInfo.PhoneNum,UserInfo.Email};                      

                        return  User;
                    }
                    catch (Exception e)
                    {
                        return null;
                    }
            }
            else
            {
                return null;
            }
        }
    }
}
