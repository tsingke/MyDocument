﻿namespace CMCCCustomeInfoManageSystem
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.CMCCMenu = new System.Windows.Forms.MenuStrip();
            this.SystemMange = new System.Windows.Forms.ToolStripMenuItem();
            this.注册新用户RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.登录LToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统QToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Function = new System.Windows.Forms.ToolStripMenuItem();
            this.查看用户信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客户概况分析ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客户忠诚度分析ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客户利润分析ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客户性能分析ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客户未来分析ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客户促销分析ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.UserID = new System.Windows.Forms.TextBox();
            this.PassWord = new System.Windows.Forms.TextBox();
            this.Login = new System.Windows.Forms.Button();
            this.ErrorMsg = new System.Windows.Forms.Label();
            this.RegisterUser = new System.Windows.Forms.Button();
            this.AdminUser = new System.Windows.Forms.RadioButton();
            this.NormalUser = new System.Windows.Forms.RadioButton();
            this.LoginPanel = new System.Windows.Forms.Panel();
            this.CMCCMenu.SuspendLayout();
            this.LoginPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // CMCCMenu
            // 
            this.CMCCMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SystemMange,
            this.Function});
            this.CMCCMenu.Location = new System.Drawing.Point(0, 0);
            this.CMCCMenu.Name = "CMCCMenu";
            this.CMCCMenu.Size = new System.Drawing.Size(909, 25);
            this.CMCCMenu.TabIndex = 0;
            this.CMCCMenu.Text = "CMCCMenu";
            // 
            // SystemMange
            // 
            this.SystemMange.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.注册新用户RToolStripMenuItem,
            this.登录LToolStripMenuItem,
            this.退出系统QToolStripMenuItem});
            this.SystemMange.Name = "SystemMange";
            this.SystemMange.Size = new System.Drawing.Size(68, 21);
            this.SystemMange.Text = "系统管理";
            // 
            // 注册新用户RToolStripMenuItem
            // 
            this.注册新用户RToolStripMenuItem.Name = "注册新用户RToolStripMenuItem";
            this.注册新用户RToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.注册新用户RToolStripMenuItem.Text = "注册新用户(&R)";
            this.注册新用户RToolStripMenuItem.Click += new System.EventHandler(this.注册新用户RToolStripMenuItem_Click);
            // 
            // 登录LToolStripMenuItem
            // 
            this.登录LToolStripMenuItem.Name = "登录LToolStripMenuItem";
            this.登录LToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.登录LToolStripMenuItem.Text = "登录(&L)";
            this.登录LToolStripMenuItem.Click += new System.EventHandler(this.登录LToolStripMenuItem_Click);
            // 
            // 退出系统QToolStripMenuItem
            // 
            this.退出系统QToolStripMenuItem.Name = "退出系统QToolStripMenuItem";
            this.退出系统QToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.退出系统QToolStripMenuItem.Text = "退出系统(&Q)";
            this.退出系统QToolStripMenuItem.Click += new System.EventHandler(this.退出系统QToolStripMenuItem_Click);
            // 
            // Function
            // 
            this.Function.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查看用户信息ToolStripMenuItem,
            this.客户概况分析ToolStripMenuItem,
            this.客户忠诚度分析ToolStripMenuItem,
            this.客户利润分析ToolStripMenuItem,
            this.客户性能分析ToolStripMenuItem,
            this.客户未来分析ToolStripMenuItem,
            this.客户促销分析ToolStripMenuItem});
            this.Function.Name = "Function";
            this.Function.Size = new System.Drawing.Size(44, 21);
            this.Function.Text = "功能";
            // 
            // 查看用户信息ToolStripMenuItem
            // 
            this.查看用户信息ToolStripMenuItem.Name = "查看用户信息ToolStripMenuItem";
            this.查看用户信息ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.查看用户信息ToolStripMenuItem.Text = "查看用户信息(&U)";
            this.查看用户信息ToolStripMenuItem.Click += new System.EventHandler(this.查看用户信息ToolStripMenuItem_Click);
            // 
            // 客户概况分析ToolStripMenuItem
            // 
            this.客户概况分析ToolStripMenuItem.Name = "客户概况分析ToolStripMenuItem";
            this.客户概况分析ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.客户概况分析ToolStripMenuItem.Text = "客户概况分析(&G)";
            this.客户概况分析ToolStripMenuItem.Click += new System.EventHandler(this.客户概况分析ToolStripMenuItem_Click);
            // 
            // 客户忠诚度分析ToolStripMenuItem
            // 
            this.客户忠诚度分析ToolStripMenuItem.Name = "客户忠诚度分析ToolStripMenuItem";
            this.客户忠诚度分析ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.客户忠诚度分析ToolStripMenuItem.Text = "客户忠诚度分析(&Z)";
            this.客户忠诚度分析ToolStripMenuItem.Click += new System.EventHandler(this.客户忠诚度分析ToolStripMenuItem_Click);
            // 
            // 客户利润分析ToolStripMenuItem
            // 
            this.客户利润分析ToolStripMenuItem.Name = "客户利润分析ToolStripMenuItem";
            this.客户利润分析ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.客户利润分析ToolStripMenuItem.Text = "客户利润分析(&L)";
            this.客户利润分析ToolStripMenuItem.Click += new System.EventHandler(this.客户利润分析ToolStripMenuItem_Click);
            // 
            // 客户性能分析ToolStripMenuItem
            // 
            this.客户性能分析ToolStripMenuItem.Name = "客户性能分析ToolStripMenuItem";
            this.客户性能分析ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.客户性能分析ToolStripMenuItem.Text = "客户性能分析(&X)";
            this.客户性能分析ToolStripMenuItem.Click += new System.EventHandler(this.客户性能分析ToolStripMenuItem_Click);
            // 
            // 客户未来分析ToolStripMenuItem
            // 
            this.客户未来分析ToolStripMenuItem.Name = "客户未来分析ToolStripMenuItem";
            this.客户未来分析ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.客户未来分析ToolStripMenuItem.Text = "客户未来分析(&W)";
            this.客户未来分析ToolStripMenuItem.Click += new System.EventHandler(this.客户未来分析ToolStripMenuItem_Click);
            // 
            // 客户促销分析ToolStripMenuItem
            // 
            this.客户促销分析ToolStripMenuItem.Name = "客户促销分析ToolStripMenuItem";
            this.客户促销分析ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.客户促销分析ToolStripMenuItem.Text = "客户促销分析(&C)";
            this.客户促销分析ToolStripMenuItem.Click += new System.EventHandler(this.客户促销分析ToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("楷体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(201, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 21);
            this.label1.TabIndex = 2;
            this.label1.Text = "用户名:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("楷体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(201, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "用户密码:";
            // 
            // UserID
            // 
            this.UserID.Font = new System.Drawing.Font("微软雅黑", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.UserID.Location = new System.Drawing.Point(328, 51);
            this.UserID.Name = "UserID";
            this.UserID.Size = new System.Drawing.Size(281, 35);
            this.UserID.TabIndex = 4;
            this.UserID.Text = "Admin";
            // 
            // PassWord
            // 
            this.PassWord.Font = new System.Drawing.Font("微软雅黑", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PassWord.Location = new System.Drawing.Point(328, 127);
            this.PassWord.Name = "PassWord";
            this.PassWord.Size = new System.Drawing.Size(281, 35);
            this.PassWord.TabIndex = 5;
            this.PassWord.Text = "Admin";
            this.PassWord.UseSystemPasswordChar = true;
            // 
            // Login
            // 
            this.Login.Font = new System.Drawing.Font("楷体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Login.Location = new System.Drawing.Point(509, 320);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(100, 35);
            this.Login.TabIndex = 6;
            this.Login.Text = "登录";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // ErrorMsg
            // 
            this.ErrorMsg.AutoSize = true;
            this.ErrorMsg.Font = new System.Drawing.Font("楷体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ErrorMsg.Location = new System.Drawing.Point(324, 252);
            this.ErrorMsg.Name = "ErrorMsg";
            this.ErrorMsg.Size = new System.Drawing.Size(0, 21);
            this.ErrorMsg.TabIndex = 7;
            // 
            // RegisterUser
            // 
            this.RegisterUser.Font = new System.Drawing.Font("楷体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.RegisterUser.Location = new System.Drawing.Point(327, 320);
            this.RegisterUser.Name = "RegisterUser";
            this.RegisterUser.Size = new System.Drawing.Size(100, 35);
            this.RegisterUser.TabIndex = 8;
            this.RegisterUser.Text = "注册";
            this.RegisterUser.UseVisualStyleBackColor = true;
            this.RegisterUser.Click += new System.EventHandler(this.RegisterUser_Click);
            // 
            // AdminUser
            // 
            this.AdminUser.AutoSize = true;
            this.AdminUser.Checked = true;
            this.AdminUser.Location = new System.Drawing.Point(328, 219);
            this.AdminUser.Name = "AdminUser";
            this.AdminUser.Size = new System.Drawing.Size(59, 16);
            this.AdminUser.TabIndex = 9;
            this.AdminUser.TabStop = true;
            this.AdminUser.Text = "管理员";
            this.AdminUser.UseVisualStyleBackColor = true;
            // 
            // NormalUser
            // 
            this.NormalUser.AutoSize = true;
            this.NormalUser.Location = new System.Drawing.Point(482, 219);
            this.NormalUser.Name = "NormalUser";
            this.NormalUser.Size = new System.Drawing.Size(71, 16);
            this.NormalUser.TabIndex = 10;
            this.NormalUser.Text = "普通用户";
            this.NormalUser.UseVisualStyleBackColor = true;
            // 
            // LoginPanel
            // 
            this.LoginPanel.Controls.Add(this.UserID);
            this.LoginPanel.Controls.Add(this.NormalUser);
            this.LoginPanel.Controls.Add(this.label1);
            this.LoginPanel.Controls.Add(this.AdminUser);
            this.LoginPanel.Controls.Add(this.label2);
            this.LoginPanel.Controls.Add(this.RegisterUser);
            this.LoginPanel.Controls.Add(this.PassWord);
            this.LoginPanel.Controls.Add(this.ErrorMsg);
            this.LoginPanel.Controls.Add(this.Login);
            this.LoginPanel.Location = new System.Drawing.Point(0, 28);
            this.LoginPanel.Name = "LoginPanel";
            this.LoginPanel.Size = new System.Drawing.Size(909, 537);
            this.LoginPanel.TabIndex = 12;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(909, 562);
            this.Controls.Add(this.LoginPanel);
            this.Controls.Add(this.CMCCMenu);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.CMCCMenu;
            this.Name = "MainForm";
            this.Text = "移动公司客户信息管理系统";
            this.CMCCMenu.ResumeLayout(false);
            this.CMCCMenu.PerformLayout();
            this.LoginPanel.ResumeLayout(false);
            this.LoginPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip CMCCMenu;
        private System.Windows.Forms.ToolStripMenuItem SystemMange;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox UserID;
        private System.Windows.Forms.TextBox PassWord;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Label ErrorMsg;
        private System.Windows.Forms.Button RegisterUser;
        private System.Windows.Forms.RadioButton AdminUser;
        private System.Windows.Forms.RadioButton NormalUser;
        private System.Windows.Forms.ToolStripMenuItem Function;
        private System.Windows.Forms.ToolStripMenuItem 查看用户信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统QToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客户概况分析ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客户忠诚度分析ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客户利润分析ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客户性能分析ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客户未来分析ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客户促销分析ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 注册新用户RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 登录LToolStripMenuItem;
        public System.Windows.Forms.Panel LoginPanel;
    }
}

