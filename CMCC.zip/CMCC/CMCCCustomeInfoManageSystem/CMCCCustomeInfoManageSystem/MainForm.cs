﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using BusinessLayer;

namespace CMCCCustomeInfoManageSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            Function.Visible = false;
        }
        Common Com = new Common();
        private void Login_Click(object sender, EventArgs e)
        {
            var userid = UserID.Text;
            var passwd = PassWord.Text;
            if (!String.IsNullOrEmpty(userid) && !String.IsNullOrEmpty(passwd))
            {
                if (AdminUser.Checked == true)
                {
                    var login = Com.UserLoginCheck(userid,passwd,"Admin");
                    if (login)
                    {
                        if (Com.SetLoginUser(userid,"Admin"))
                        {
                            注册新用户RToolStripMenuItem.Visible = false;
                            登录LToolStripMenuItem.Visible = false;
                            LoginPanel.Visible = false;
                            Function.Visible = true;
                            ControlPanel UC = new ControlPanel();
                            UC.MdiParent = this;
                            UC.WindowState = FormWindowState.Maximized;
                            UC.Show();
                        }
                        else
                        {
                            ErrorMsg.Text = "登录失败.";
                        }
                    }
                    else
                    {
                        ErrorMsg.Text = "登录失败.";
                    }
                }
                else
                {
                    var login = Com.UserLoginCheck(userid, passwd, "Normal");
                    if (login)
                    {
                        if (Com.SetLoginUser(userid, "Normal"))
                        {
                            注册新用户RToolStripMenuItem.Visible = false;
                            登录LToolStripMenuItem.Visible = false;
                            LoginPanel.Visible = false;
                            Function.Visible = true;
                            ControlPanel UC = new ControlPanel();
                            UC.MdiParent = this;
                            UC.WindowState = FormWindowState.Maximized;
                            UC.Show();
                        }
                        else
                        {
                            ErrorMsg.Text = "登录失败.";
                        }
                    }
                    else
                    {
                        ErrorMsg.Text = "登录失败.";
                    }
                }
            }
            else
            {
                ErrorMsg.Text = "登录失败，失败信息：用户名和密码不能为空。";
            }
        }

        private void 退出系统QToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dispose();
            this.Dispose();
        }

        private void 查看用户信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewUserInfo VU = new ViewUserInfo();
            VU.MdiParent = this;
            VU.WindowState = FormWindowState.Maximized;            
            VU.Show();
        }

        private void RegisterUser_Click(object sender, EventArgs e)
        {
            LoginPanel.Visible = false;
            RegisterPage RP = new RegisterPage();
            RP.MdiParent = this;
            RP.WindowState = FormWindowState.Maximized;
            RP.Show();
        }

        private void 客户概况分析ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeHuGaiKuang KFGK = new KeHuGaiKuang();
            KFGK.MdiParent = this;
            KFGK.WindowState = FormWindowState.Maximized;
            KFGK.Show();

        }

        private void 注册新用户RToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoginPanel.Visible = false;
            RegisterPage RP = new RegisterPage();
            RP.MdiParent = this;
            RP.WindowState = FormWindowState.Maximized;
            RP.Show();
        }

        private void 客户忠诚度分析ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeHuZhongChengDu KHZCD = new KeHuZhongChengDu();
            KHZCD.MdiParent = this;
            KHZCD.WindowState = FormWindowState.Maximized;
            KHZCD.Show();
        }

        private void 客户利润分析ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeHuLiRun KHLR = new KeHuLiRun();
            KHLR.MdiParent = this;
            KHLR.WindowState = FormWindowState.Maximized;
            KHLR.Show();
        }

        private void 客户性能分析ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeHuXingNeng KHXN = new KeHuXingNeng();
            KHXN.MdiParent = this;
            KHXN.WindowState = FormWindowState.Maximized;
            KHXN.Show();
        }

        private void 客户未来分析ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeHuWeiLai KHWL = new KeHuWeiLai();
            KHWL.MdiParent = this;
            KHWL.WindowState = FormWindowState.Maximized;
            KHWL.Show();
        }

        private void 客户促销分析ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeHuCuXiao KHCX = new KeHuCuXiao();
            KHCX.MdiParent = this;
            KHCX.WindowState = FormWindowState.Maximized;
            KHCX.Show();
        }

        private void 登录LToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoginPanel.Visible = true;
        }
    }
}
