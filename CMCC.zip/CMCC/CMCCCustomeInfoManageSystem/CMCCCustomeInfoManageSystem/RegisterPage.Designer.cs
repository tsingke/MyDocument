﻿namespace CMCCCustomeInfoManageSystem
{
    partial class RegisterPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RegisterUserPanel = new System.Windows.Forms.Panel();
            this.LBWarnningMsg = new System.Windows.Forms.Label();
            this.RolePanel = new System.Windows.Forms.Panel();
            this.RDNormal = new System.Windows.Forms.RadioButton();
            this.RDAdmin = new System.Windows.Forms.RadioButton();
            this.SEXPanel = new System.Windows.Forms.Panel();
            this.RDWoman = new System.Windows.Forms.RadioButton();
            this.RDMan = new System.Windows.Forms.RadioButton();
            this.Birthday = new System.Windows.Forms.DateTimePicker();
            this.UserName = new System.Windows.Forms.TextBox();
            this.PhoneNum = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.PassWord = new System.Windows.Forms.TextBox();
            this.UserID = new System.Windows.Forms.TextBox();
            this.SureReg = new System.Windows.Forms.Button();
            this.CancelReg = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.RegisterUserPanel.SuspendLayout();
            this.RolePanel.SuspendLayout();
            this.SEXPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // RegisterUserPanel
            // 
            this.RegisterUserPanel.Controls.Add(this.LBWarnningMsg);
            this.RegisterUserPanel.Controls.Add(this.RolePanel);
            this.RegisterUserPanel.Controls.Add(this.SEXPanel);
            this.RegisterUserPanel.Controls.Add(this.Birthday);
            this.RegisterUserPanel.Controls.Add(this.UserName);
            this.RegisterUserPanel.Controls.Add(this.PhoneNum);
            this.RegisterUserPanel.Controls.Add(this.Email);
            this.RegisterUserPanel.Controls.Add(this.PassWord);
            this.RegisterUserPanel.Controls.Add(this.UserID);
            this.RegisterUserPanel.Controls.Add(this.SureReg);
            this.RegisterUserPanel.Controls.Add(this.CancelReg);
            this.RegisterUserPanel.Controls.Add(this.label8);
            this.RegisterUserPanel.Controls.Add(this.label7);
            this.RegisterUserPanel.Controls.Add(this.label6);
            this.RegisterUserPanel.Controls.Add(this.label5);
            this.RegisterUserPanel.Controls.Add(this.label4);
            this.RegisterUserPanel.Controls.Add(this.label3);
            this.RegisterUserPanel.Controls.Add(this.label2);
            this.RegisterUserPanel.Controls.Add(this.label1);
            this.RegisterUserPanel.Location = new System.Drawing.Point(-1, 0);
            this.RegisterUserPanel.Name = "RegisterUserPanel";
            this.RegisterUserPanel.Size = new System.Drawing.Size(887, 560);
            this.RegisterUserPanel.TabIndex = 0;
            // 
            // LBWarnningMsg
            // 
            this.LBWarnningMsg.AutoSize = true;
            this.LBWarnningMsg.ForeColor = System.Drawing.Color.Red;
            this.LBWarnningMsg.Location = new System.Drawing.Point(662, 45);
            this.LBWarnningMsg.Name = "LBWarnningMsg";
            this.LBWarnningMsg.Size = new System.Drawing.Size(0, 12);
            this.LBWarnningMsg.TabIndex = 26;
            // 
            // RolePanel
            // 
            this.RolePanel.Controls.Add(this.RDNormal);
            this.RolePanel.Controls.Add(this.RDAdmin);
            this.RolePanel.Location = new System.Drawing.Point(304, 64);
            this.RolePanel.Name = "RolePanel";
            this.RolePanel.Size = new System.Drawing.Size(310, 50);
            this.RolePanel.TabIndex = 25;
            // 
            // RDNormal
            // 
            this.RDNormal.AutoSize = true;
            this.RDNormal.Location = new System.Drawing.Point(231, 14);
            this.RDNormal.Name = "RDNormal";
            this.RDNormal.Size = new System.Drawing.Size(71, 16);
            this.RDNormal.TabIndex = 20;
            this.RDNormal.Text = "普通用户";
            this.RDNormal.UseVisualStyleBackColor = true;
            // 
            // RDAdmin
            // 
            this.RDAdmin.AutoSize = true;
            this.RDAdmin.Checked = true;
            this.RDAdmin.Location = new System.Drawing.Point(30, 14);
            this.RDAdmin.Name = "RDAdmin";
            this.RDAdmin.Size = new System.Drawing.Size(59, 16);
            this.RDAdmin.TabIndex = 19;
            this.RDAdmin.TabStop = true;
            this.RDAdmin.Text = "管理员";
            this.RDAdmin.UseVisualStyleBackColor = true;
            // 
            // SEXPanel
            // 
            this.SEXPanel.Controls.Add(this.RDWoman);
            this.SEXPanel.Controls.Add(this.RDMan);
            this.SEXPanel.Location = new System.Drawing.Point(304, 147);
            this.SEXPanel.Name = "SEXPanel";
            this.SEXPanel.Size = new System.Drawing.Size(310, 49);
            this.SEXPanel.TabIndex = 24;
            // 
            // RDWoman
            // 
            this.RDWoman.AutoSize = true;
            this.RDWoman.Location = new System.Drawing.Point(231, 16);
            this.RDWoman.Name = "RDWoman";
            this.RDWoman.Size = new System.Drawing.Size(35, 16);
            this.RDWoman.TabIndex = 25;
            this.RDWoman.Text = "女";
            this.RDWoman.UseVisualStyleBackColor = true;
            // 
            // RDMan
            // 
            this.RDMan.AutoSize = true;
            this.RDMan.Checked = true;
            this.RDMan.Location = new System.Drawing.Point(30, 16);
            this.RDMan.Name = "RDMan";
            this.RDMan.Size = new System.Drawing.Size(35, 16);
            this.RDMan.TabIndex = 24;
            this.RDMan.TabStop = true;
            this.RDMan.Text = "男";
            this.RDMan.UseVisualStyleBackColor = true;
            // 
            // Birthday
            // 
            this.Birthday.Location = new System.Drawing.Point(304, 202);
            this.Birthday.Name = "Birthday";
            this.Birthday.Size = new System.Drawing.Size(310, 21);
            this.Birthday.TabIndex = 21;
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(304, 120);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(310, 21);
            this.UserName.TabIndex = 16;
            // 
            // PhoneNum
            // 
            this.PhoneNum.Location = new System.Drawing.Point(304, 238);
            this.PhoneNum.Name = "PhoneNum";
            this.PhoneNum.Size = new System.Drawing.Size(310, 21);
            this.PhoneNum.TabIndex = 13;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(304, 280);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(310, 21);
            this.Email.TabIndex = 12;
            // 
            // PassWord
            // 
            this.PassWord.Location = new System.Drawing.Point(304, 317);
            this.PassWord.Name = "PassWord";
            this.PassWord.Size = new System.Drawing.Size(310, 21);
            this.PassWord.TabIndex = 11;
            // 
            // UserID
            // 
            this.UserID.Location = new System.Drawing.Point(304, 37);
            this.UserID.Name = "UserID";
            this.UserID.Size = new System.Drawing.Size(310, 21);
            this.UserID.TabIndex = 10;
            this.UserID.Leave += new System.EventHandler(this.UserID_Leave);
            // 
            // SureReg
            // 
            this.SureReg.Location = new System.Drawing.Point(539, 396);
            this.SureReg.Name = "SureReg";
            this.SureReg.Size = new System.Drawing.Size(75, 23);
            this.SureReg.TabIndex = 9;
            this.SureReg.Text = "确认";
            this.SureReg.UseVisualStyleBackColor = true;
            this.SureReg.Click += new System.EventHandler(this.SureReg_Click);
            // 
            // CancelReg
            // 
            this.CancelReg.Location = new System.Drawing.Point(304, 396);
            this.CancelReg.Name = "CancelReg";
            this.CancelReg.Size = new System.Drawing.Size(75, 23);
            this.CancelReg.TabIndex = 8;
            this.CancelReg.Text = "取消";
            this.CancelReg.UseVisualStyleBackColor = true;
            this.CancelReg.Click += new System.EventHandler(this.CancelReg_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(207, 326);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "登录密码:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(207, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "电子邮箱:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(207, 247);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "手机号码:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(207, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "出生日期:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(207, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "用户性别:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(207, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "用户姓名:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "用户角色:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(205, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "登录ID:";
            // 
            // RegisterPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 562);
            this.Controls.Add(this.RegisterUserPanel);
            this.Name = "RegisterPage";
            this.Text = "注册新用户";
            this.RegisterUserPanel.ResumeLayout(false);
            this.RegisterUserPanel.PerformLayout();
            this.RolePanel.ResumeLayout(false);
            this.RolePanel.PerformLayout();
            this.SEXPanel.ResumeLayout(false);
            this.SEXPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel RegisterUserPanel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SureReg;
        private System.Windows.Forms.Button CancelReg;
        private System.Windows.Forms.TextBox UserName;
        private System.Windows.Forms.TextBox PhoneNum;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox PassWord;
        private System.Windows.Forms.TextBox UserID;
        private System.Windows.Forms.DateTimePicker Birthday;
        private System.Windows.Forms.Panel SEXPanel;
        private System.Windows.Forms.RadioButton RDWoman;
        private System.Windows.Forms.RadioButton RDMan;
        private System.Windows.Forms.Panel RolePanel;
        private System.Windows.Forms.RadioButton RDNormal;
        private System.Windows.Forms.RadioButton RDAdmin;
        private System.Windows.Forms.Label LBWarnningMsg;
    }
}