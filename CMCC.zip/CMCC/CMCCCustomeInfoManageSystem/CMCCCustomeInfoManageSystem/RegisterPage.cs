﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using BusinessLayer;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Diagnostics;


namespace CMCCCustomeInfoManageSystem
{
    public partial class RegisterPage : Form
    {
        public RegisterPage()
        {
            InitializeComponent();
            Form.CheckForIllegalCrossThreadCalls = false;
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        Common Com = new Common();
        private void CancelReg_Click(object sender, EventArgs e)
        {
            this.Dispose();          
        }

        private void SureReg_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(new ThreadStart(AddUser));
            th.IsBackground = true;
            th.Start();
            
        }
        public void AddUser()
        {
            var ID = UserID.Text;
            var userrole = RDAdmin.Checked == true ? "Admin" : "Normal";
            var Name = UserName.Text;
            int usersex = RDMan.Checked == true ? 1 : 0;
            DateTime birth = Convert.ToDateTime(Birthday.Text);
            var phone = PhoneNum.Text;
            var email = Email.Text;
            var passwd = PassWord.Text;
            if (Com.AddUser(ID, userrole, Name, usersex, birth, phone, email, passwd))
            {
                MessageBox.Show("恭喜您：" + ID + ",您已经注册成功。");
                this.Dispose();
            }
            else
            {
                MessageBox.Show("注册失败。请重试。");
            }
        }

        private void UserID_Leave(object sender, EventArgs e)
        {
            if(UserID.Text != "")
            {
                if (Com.CheckUserID(UserID.Text))
                {
                    LBWarnningMsg.Text = "";
                    LBWarnningMsg.Text = "当前用户名可用。";
                }
                else
                {
                    LBWarnningMsg.Text = "";
                    LBWarnningMsg.Text="当前用户名不可用。";
                }
            }
        }
    }
}
