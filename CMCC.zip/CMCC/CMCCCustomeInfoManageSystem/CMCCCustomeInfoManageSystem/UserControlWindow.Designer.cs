﻿namespace CMCCCustomeInfoManageSystem
{
    partial class ControlPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.KeHuGaiKuang = new System.Windows.Forms.Button();
            this.KeHuZhongChengDU = new System.Windows.Forms.Button();
            this.KeHuLiRun = new System.Windows.Forms.Button();
            this.KeHuXingNeng = new System.Windows.Forms.Button();
            this.KeHuWeiLai = new System.Windows.Forms.Button();
            this.KeHuCuXiao = new System.Windows.Forms.Button();
            this.ViewUserInfo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // KeHuGaiKuang
            // 
            this.KeHuGaiKuang.Location = new System.Drawing.Point(265, 95);
            this.KeHuGaiKuang.Name = "KeHuGaiKuang";
            this.KeHuGaiKuang.Size = new System.Drawing.Size(139, 23);
            this.KeHuGaiKuang.TabIndex = 0;
            this.KeHuGaiKuang.Text = "客户概况分析";
            this.KeHuGaiKuang.UseVisualStyleBackColor = true;
            this.KeHuGaiKuang.Click += new System.EventHandler(this.KeHuGaiKuang_Click);
            // 
            // KeHuZhongChengDU
            // 
            this.KeHuZhongChengDU.Location = new System.Drawing.Point(478, 95);
            this.KeHuZhongChengDU.Name = "KeHuZhongChengDU";
            this.KeHuZhongChengDU.Size = new System.Drawing.Size(140, 23);
            this.KeHuZhongChengDU.TabIndex = 1;
            this.KeHuZhongChengDU.Text = "客户忠诚度分析";
            this.KeHuZhongChengDU.UseVisualStyleBackColor = true;
            this.KeHuZhongChengDU.Click += new System.EventHandler(this.KeHuZhongChengDU_Click);
            // 
            // KeHuLiRun
            // 
            this.KeHuLiRun.Location = new System.Drawing.Point(265, 233);
            this.KeHuLiRun.Name = "KeHuLiRun";
            this.KeHuLiRun.Size = new System.Drawing.Size(139, 23);
            this.KeHuLiRun.TabIndex = 2;
            this.KeHuLiRun.Text = "客户利润分析";
            this.KeHuLiRun.UseVisualStyleBackColor = true;
            this.KeHuLiRun.Click += new System.EventHandler(this.KeHuLiRun_Click);
            // 
            // KeHuXingNeng
            // 
            this.KeHuXingNeng.Location = new System.Drawing.Point(478, 233);
            this.KeHuXingNeng.Name = "KeHuXingNeng";
            this.KeHuXingNeng.Size = new System.Drawing.Size(140, 23);
            this.KeHuXingNeng.TabIndex = 3;
            this.KeHuXingNeng.Text = "客户性能分析";
            this.KeHuXingNeng.UseVisualStyleBackColor = true;
            this.KeHuXingNeng.Click += new System.EventHandler(this.KeHuXingNeng_Click);
            // 
            // KeHuWeiLai
            // 
            this.KeHuWeiLai.Location = new System.Drawing.Point(265, 372);
            this.KeHuWeiLai.Name = "KeHuWeiLai";
            this.KeHuWeiLai.Size = new System.Drawing.Size(139, 23);
            this.KeHuWeiLai.TabIndex = 4;
            this.KeHuWeiLai.Text = "客户未来分析";
            this.KeHuWeiLai.UseVisualStyleBackColor = true;
            this.KeHuWeiLai.Click += new System.EventHandler(this.KeHuWeiLai_Click);
            // 
            // KeHuCuXiao
            // 
            this.KeHuCuXiao.Location = new System.Drawing.Point(478, 372);
            this.KeHuCuXiao.Name = "KeHuCuXiao";
            this.KeHuCuXiao.Size = new System.Drawing.Size(140, 23);
            this.KeHuCuXiao.TabIndex = 5;
            this.KeHuCuXiao.Text = "客户促销分析";
            this.KeHuCuXiao.UseVisualStyleBackColor = true;
            this.KeHuCuXiao.Click += new System.EventHandler(this.KeHuCuXiao_Click);
            // 
            // ViewUserInfo
            // 
            this.ViewUserInfo.Location = new System.Drawing.Point(71, 233);
            this.ViewUserInfo.Name = "ViewUserInfo";
            this.ViewUserInfo.Size = new System.Drawing.Size(104, 23);
            this.ViewUserInfo.TabIndex = 6;
            this.ViewUserInfo.Text = "查看用户信息";
            this.ViewUserInfo.UseVisualStyleBackColor = true;
            this.ViewUserInfo.Click += new System.EventHandler(this.ViewUserInfo_Click);
            // 
            // ControlPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 562);
            this.Controls.Add(this.ViewUserInfo);
            this.Controls.Add(this.KeHuCuXiao);
            this.Controls.Add(this.KeHuWeiLai);
            this.Controls.Add(this.KeHuXingNeng);
            this.Controls.Add(this.KeHuLiRun);
            this.Controls.Add(this.KeHuZhongChengDU);
            this.Controls.Add(this.KeHuGaiKuang);
            this.Name = "ControlPanel";
            this.Text = "控制面板";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button KeHuGaiKuang;
        private System.Windows.Forms.Button KeHuZhongChengDU;
        private System.Windows.Forms.Button KeHuLiRun;
        private System.Windows.Forms.Button KeHuXingNeng;
        private System.Windows.Forms.Button KeHuWeiLai;
        private System.Windows.Forms.Button KeHuCuXiao;
        private System.Windows.Forms.Button ViewUserInfo;
    }
}