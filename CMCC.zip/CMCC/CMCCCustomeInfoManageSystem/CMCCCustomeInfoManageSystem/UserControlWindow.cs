﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CMCCCustomeInfoManageSystem
{
    public partial class ControlPanel : Form
    {
        public ControlPanel()
        {
            InitializeComponent();
        }

        private void ViewUserInfo_Click(object sender, EventArgs e)
        {
            ViewUserInfo VU = new ViewUserInfo();
            VU.MdiParent = MainForm.ActiveForm;
            VU.WindowState = FormWindowState.Maximized;
            VU.Show();
        }

        private void KeHuGaiKuang_Click(object sender, EventArgs e)
        {
            KeHuGaiKuang KFGK = new KeHuGaiKuang();
            KFGK.MdiParent = MainForm.ActiveForm;
            KFGK.WindowState = FormWindowState.Maximized;
            KFGK.Show();
        }

        private void KeHuZhongChengDU_Click(object sender, EventArgs e)
        {
            KeHuZhongChengDu KHZCD = new KeHuZhongChengDu();
            KHZCD.MdiParent = MainForm.ActiveForm;
            KHZCD.WindowState = FormWindowState.Maximized;
            KHZCD.Show();
        }

        private void KeHuLiRun_Click(object sender, EventArgs e)
        {
            KeHuLiRun KHLR = new KeHuLiRun();
            KHLR.MdiParent = MainForm.ActiveForm;
            KHLR.WindowState = FormWindowState.Maximized;
            KHLR.Show();
        }

        private void KeHuXingNeng_Click(object sender, EventArgs e)
        {
            KeHuXingNeng KHXN = new KeHuXingNeng();
            KHXN.MdiParent = MainForm.ActiveForm;
            KHXN.WindowState = FormWindowState.Maximized;
            KHXN.Show();
        }

        private void KeHuWeiLai_Click(object sender, EventArgs e)
        {
            KeHuWeiLai KHWL = new KeHuWeiLai();
            KHWL.MdiParent = MainForm.ActiveForm;
            KHWL.WindowState = FormWindowState.Maximized;
            KHWL.Show();
        }

        private void KeHuCuXiao_Click(object sender, EventArgs e)
        {
            KeHuCuXiao KHCX = new KeHuCuXiao();
            KHCX.MdiParent = MainForm.ActiveForm;
            KHCX.WindowState = FormWindowState.Maximized;
            KHCX.Show();
        }
    }
}
