﻿namespace CMCCCustomeInfoManageSystem
{
    partial class ViewUserInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserInfoPanel = new System.Windows.Forms.Panel();
            this.ChangPwdPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.UserID = new System.Windows.Forms.TextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.RolePanel = new System.Windows.Forms.Panel();
            this.RDNormal = new System.Windows.Forms.RadioButton();
            this.RDAdmin = new System.Windows.Forms.RadioButton();
            this.SEXPanel = new System.Windows.Forms.Panel();
            this.RDWoman = new System.Windows.Forms.RadioButton();
            this.RDMan = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.UserName = new System.Windows.Forms.TextBox();
            this.Birthday = new System.Windows.Forms.DateTimePicker();
            this.PhoneNum = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.UserInfoPanel.SuspendLayout();
            this.RolePanel.SuspendLayout();
            this.SEXPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // UserInfoPanel
            // 
            this.UserInfoPanel.Controls.Add(this.Email);
            this.UserInfoPanel.Controls.Add(this.PhoneNum);
            this.UserInfoPanel.Controls.Add(this.Birthday);
            this.UserInfoPanel.Controls.Add(this.UserName);
            this.UserInfoPanel.Controls.Add(this.label7);
            this.UserInfoPanel.Controls.Add(this.SEXPanel);
            this.UserInfoPanel.Controls.Add(this.RolePanel);
            this.UserInfoPanel.Controls.Add(this.UserID);
            this.UserInfoPanel.Controls.Add(this.label6);
            this.UserInfoPanel.Controls.Add(this.label5);
            this.UserInfoPanel.Controls.Add(this.label4);
            this.UserInfoPanel.Controls.Add(this.label3);
            this.UserInfoPanel.Controls.Add(this.label2);
            this.UserInfoPanel.Controls.Add(this.label1);
            this.UserInfoPanel.Location = new System.Drawing.Point(147, 10);
            this.UserInfoPanel.Name = "UserInfoPanel";
            this.UserInfoPanel.Size = new System.Drawing.Size(595, 537);
            this.UserInfoPanel.TabIndex = 0;
            // 
            // ChangPwdPanel
            // 
            this.ChangPwdPanel.Location = new System.Drawing.Point(147, 10);
            this.ChangPwdPanel.Name = "ChangPwdPanel";
            this.ChangPwdPanel.Size = new System.Drawing.Size(478, 534);
            this.ChangPwdPanel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "用户ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "用户角色:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "性别:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 284);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "出生日期:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 369);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "电话号码:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 439);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "电子邮件:";
            // 
            // UserID
            // 
            this.UserID.Location = new System.Drawing.Point(133, 11);
            this.UserID.Name = "UserID";
            this.UserID.ReadOnly = true;
            this.UserID.Size = new System.Drawing.Size(310, 21);
            this.UserID.TabIndex = 6;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 562);
            this.splitter1.TabIndex = 2;
            this.splitter1.TabStop = false;
            // 
            // RolePanel
            // 
            this.RolePanel.Controls.Add(this.RDNormal);
            this.RolePanel.Controls.Add(this.RDAdmin);
            this.RolePanel.Location = new System.Drawing.Point(133, 118);
            this.RolePanel.Name = "RolePanel";
            this.RolePanel.Size = new System.Drawing.Size(310, 50);
            this.RolePanel.TabIndex = 26;
            // 
            // RDNormal
            // 
            this.RDNormal.AutoSize = true;
            this.RDNormal.Location = new System.Drawing.Point(231, 14);
            this.RDNormal.Name = "RDNormal";
            this.RDNormal.Size = new System.Drawing.Size(71, 16);
            this.RDNormal.TabIndex = 20;
            this.RDNormal.Text = "普通用户";
            this.RDNormal.UseVisualStyleBackColor = true;
            // 
            // RDAdmin
            // 
            this.RDAdmin.AutoSize = true;
            this.RDAdmin.Checked = true;
            this.RDAdmin.Location = new System.Drawing.Point(30, 14);
            this.RDAdmin.Name = "RDAdmin";
            this.RDAdmin.Size = new System.Drawing.Size(59, 16);
            this.RDAdmin.TabIndex = 19;
            this.RDAdmin.TabStop = true;
            this.RDAdmin.Text = "管理员";
            this.RDAdmin.UseVisualStyleBackColor = true;
            // 
            // SEXPanel
            // 
            this.SEXPanel.Controls.Add(this.RDWoman);
            this.SEXPanel.Controls.Add(this.RDMan);
            this.SEXPanel.Location = new System.Drawing.Point(133, 189);
            this.SEXPanel.Name = "SEXPanel";
            this.SEXPanel.Size = new System.Drawing.Size(310, 49);
            this.SEXPanel.TabIndex = 27;
            // 
            // RDWoman
            // 
            this.RDWoman.AutoSize = true;
            this.RDWoman.Location = new System.Drawing.Point(231, 16);
            this.RDWoman.Name = "RDWoman";
            this.RDWoman.Size = new System.Drawing.Size(35, 16);
            this.RDWoman.TabIndex = 25;
            this.RDWoman.Text = "女";
            this.RDWoman.UseVisualStyleBackColor = true;
            // 
            // RDMan
            // 
            this.RDMan.AutoSize = true;
            this.RDMan.Checked = true;
            this.RDMan.Location = new System.Drawing.Point(30, 16);
            this.RDMan.Name = "RDMan";
            this.RDMan.Size = new System.Drawing.Size(35, 16);
            this.RDMan.TabIndex = 24;
            this.RDMan.TabStop = true;
            this.RDMan.Text = "男";
            this.RDMan.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 65);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 12);
            this.label7.TabIndex = 29;
            this.label7.Text = "用户姓名:";
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(133, 65);
            this.UserName.Name = "UserName";
            this.UserName.ReadOnly = true;
            this.UserName.Size = new System.Drawing.Size(310, 21);
            this.UserName.TabIndex = 30;
            // 
            // Birthday
            // 
            this.Birthday.Enabled = false;
            this.Birthday.Location = new System.Drawing.Point(133, 278);
            this.Birthday.Name = "Birthday";
            this.Birthday.Size = new System.Drawing.Size(310, 21);
            this.Birthday.TabIndex = 31;
            // 
            // PhoneNum
            // 
            this.PhoneNum.Location = new System.Drawing.Point(133, 359);
            this.PhoneNum.Name = "PhoneNum";
            this.PhoneNum.ReadOnly = true;
            this.PhoneNum.Size = new System.Drawing.Size(310, 21);
            this.PhoneNum.TabIndex = 32;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(133, 430);
            this.Email.Name = "Email";
            this.Email.ReadOnly = true;
            this.Email.Size = new System.Drawing.Size(310, 21);
            this.Email.TabIndex = 33;
            // 
            // ViewUserInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 562);
            this.Controls.Add(this.UserInfoPanel);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.ChangPwdPanel);
            this.Name = "ViewUserInfo";
            this.Text = "查看用户信息";
            this.Load += new System.EventHandler(this.ViewUserInfo_Load);
            this.UserInfoPanel.ResumeLayout(false);
            this.UserInfoPanel.PerformLayout();
            this.RolePanel.ResumeLayout(false);
            this.RolePanel.PerformLayout();
            this.SEXPanel.ResumeLayout(false);
            this.SEXPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel UserInfoPanel;
        private System.Windows.Forms.Panel ChangPwdPanel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox UserID;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel RolePanel;
        private System.Windows.Forms.RadioButton RDNormal;
        private System.Windows.Forms.RadioButton RDAdmin;
        private System.Windows.Forms.Panel SEXPanel;
        private System.Windows.Forms.RadioButton RDWoman;
        private System.Windows.Forms.RadioButton RDMan;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox UserName;
        private System.Windows.Forms.DateTimePicker Birthday;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox PhoneNum;

    }
}