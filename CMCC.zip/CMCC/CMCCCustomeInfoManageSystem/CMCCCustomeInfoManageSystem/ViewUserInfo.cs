﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using BusinessLayer;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Diagnostics;

namespace CMCCCustomeInfoManageSystem
{
    public partial class ViewUserInfo : Form
    {
        public ViewUserInfo()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        Common Com = new Common();
        private void ViewUserInfo_Load(object sender, EventArgs e)
        {
            var LoginUser = Com.GetLoginUser();
            var LoginRole = Com.GetLoginRole();
            var UserInfo = Com.GetUserInfo(LoginUser);
            if (UserInfo != null)
            {
                    UserID.Text =UserInfo[0];
                    UserName.Text = UserInfo[1];
                    if (UserInfo[2] == "0")
                    {
                        RDWoman.Checked = true;
                    }
                    else
                    {
                        RDMan.Checked = true;
                    }
                    if (LoginRole == "Admin")
                    {
                        RDAdmin.Checked = true;
                    }
                    else
                    {
                        RDNormal.Checked = true;
                    }
                Birthday.Text = UserInfo[3];
                PhoneNum.Text = UserInfo[4];
                Email.Text = UserInfo[5];
            }
            else
            {
                MessageBox.Show("暂未获取到用户信息，请稍后重试。");
                UserInfoPanel.Visible = false;
            }
        }
    }
}
