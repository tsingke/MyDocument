﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;

using COL.DataBaseLayer;


namespace COL.BusinessLayer
{
    public class Common
    {
        COLDBADataContext COL = new COLDBADataContext();
        public static void ControlLogRecoder(string controltype, string controlog)
        {
                try
                {
                    string SavePath = "C:\\COL\\COLDebugLog";
                    if (!Directory.Exists(SavePath))
                    {
                        Directory.CreateDirectory(SavePath);
                        File.Create(SavePath + "\\DebugLog.log").Close();
                    }
                    else
                    {
                    }
                    StreamWriter ControlLog = new StreamWriter("C:\\COL\\COLDebugLog\\DebugLog.log", true);
                    ControlLog.WriteLine("Time:" + System.DateTime.Now + "\nControlType:" + controltype + "\nControlData:" + controlog + "\n");
                    ControlLog.Close();
                }
                catch (Exception e)
                {
                }
        }
        public bool Login(string UserID, string Password)
        {
            var pwd = StringToMD5(Password, UserID);
            ControlLogRecoder(MethodBase.GetCurrentMethod().Name, "\nUserID=" + UserID + "  PassWord=" + Password);
            using (COL)
            {
                try
                {
                    return COL.UserInfo.Where(p => p.UserID == UserID && p.PassWord == pwd).Count() == 0 ? false : true;
                }
                catch (Exception e)
                {
                    ControlLogRecoder(MethodBase.GetCurrentMethod().Name,"ErrorMsg:"+e.Message);
                    return false;
                }                
            }
        }
        public string StringToMD5(string todecodestring,string salt)
        {
            if (!String.IsNullOrEmpty(salt))
            {
                string rawpass = EncodingMD5(todecodestring);
                return EncodingMD5(rawpass +"{"+salt.ToString() +"}");
            }
            else
            {
                return EncodingMD5(todecodestring);
            }
        }
        public string EncodingMD5(string sourcestring)
        {
            MD5 md5 = MD5.Create();
            byte[] bs = Encoding.UTF8.GetBytes(sourcestring);
            byte[] hs = md5.ComputeHash(bs);
            StringBuilder sb = new StringBuilder();
            foreach (byte b in hs)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }
    }
}
