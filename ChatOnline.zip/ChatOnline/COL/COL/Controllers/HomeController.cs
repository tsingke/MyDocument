﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using COL.BusinessLayer;

namespace COL.Controllers
{
    public class HomeController : Controller
    {
        Common com = new Common();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public bool LoginCheck(string UserID, string PassWord)
        {
            return com.Login(UserID, PassWord);
        }
    }
}
