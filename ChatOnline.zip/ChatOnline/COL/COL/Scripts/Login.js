﻿function con(flag,value) {
    if (flag == 1) {
        console.log(value);
    }
}
function Login(UserName, PassWord) {
    $.ajax({
        type:"POST",
        url: "/Home/LoginCheck/?UserID=" + UserName + "&&PassWord=" + PassWord,
        dataType: 'Text',
        error: function (x,e) {
            con(1, e);
        },
        success: function (result) {
            con(1, result);
            if (result == "True") {
                window.location.href = "../../Home/index";
            }
        }
    });
}