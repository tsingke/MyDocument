﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace EasySystemTools
{
  public partial class AboutSoftWare : Form
  {
    public AboutSoftWare()
    {
      InitializeComponent();
    }

    private void AboutSoftWare_Load(object sender, EventArgs e)
    {
      string appname = System.Configuration.ConfigurationManager.AppSettings["SoftWare-Name"];
      string author = System.Configuration.ConfigurationManager.AppSettings["Author"];
      string version = System.Configuration.ConfigurationManager.AppSettings["Version"];
      string copyright = System.Configuration.ConfigurationManager.AppSettings["CopyRight"];
      string companyname = System.Configuration.ConfigurationManager.AppSettings["Company-Name"];
      label1.Text = appname;
      label2.Text = author;
      label3.Text = version;
      label4.Text = copyright;
      label5.Text = companyname;
    }

    private void OK_Click(object sender, EventArgs e)
    {
      Dispose();
      this.Close();
    }


  }
}
