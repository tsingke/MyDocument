﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.NetworkInformation;

namespace EasySystemTools.Bussiness
{
    class Function
    {
        public static void CreateNewProcess(String option)
        {
            System.Diagnostics.ProcessStartInfo start = new System.Diagnostics.ProcessStartInfo(option);
            start.WindowStyle = System.Diagnostics.ProcessWindowStyle.Maximized;
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            process.StartInfo = start;
            process.Start();
        }
        public static void CreateBrowserProcess(String option, String address)
        {
            System.Diagnostics.ProcessStartInfo start = new System.Diagnostics.ProcessStartInfo(option);
            start.WindowStyle = System.Diagnostics.ProcessWindowStyle.Maximized;
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            start.Arguments = address;
            process.StartInfo = start;
            process.Start();
        }
        public static string GetIpAddress()
        {
            IPHostEntry iphost = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipad = iphost.AddressList[1];
            string ip = ipad.ToString();
            return ip;
        }
        //public static string GetDNSAddress()
        //{
        //    NetworkInterface[] net = NetworkInterface.GetAllNetworkInterfaces();
        //    foreach(NetworkInterface a in net)
        //    {
        //    IPInterfaceProperties ip = a.GetIPProperties();
        //    }
        //    //string res = null;
        //    //NetworkInterface[] net = NetworkInterface.GetAllNetworkInterfaces();
        //    //foreach (NetworkInterface ad in net)
        //    //{
        //    //    bool judge = (ad.NetworkInterfaceType == NetworkInterfaceType.Ethernet);
        //    //    if (judge)
        //    //    {
        //    //        IPInterfaceProperties ip = ad.GetIPProperties();
        //    //        int dnscount = ip.DnsAddresses.Count;
        //    //        res = dnscount.ToString();
        //    //        return res;
        //    //    }
        //    //    else return res;
        //    }
        }
    }

