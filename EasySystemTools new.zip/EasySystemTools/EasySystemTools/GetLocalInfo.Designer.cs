﻿namespace EasySystemTools
{
  partial class GetLocalInfo
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GetLocalInfo));
      this.GetIpAddress = new System.Windows.Forms.Button();
      this.GetDNSAddress = new System.Windows.Forms.Button();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // GetIpAddress
      // 
      this.GetIpAddress.Location = new System.Drawing.Point(102, 28);
      this.GetIpAddress.Name = "GetIpAddress";
      this.GetIpAddress.Size = new System.Drawing.Size(111, 23);
      this.GetIpAddress.TabIndex = 0;
      this.GetIpAddress.Text = "GetLocalIpAddress";
      this.GetIpAddress.UseVisualStyleBackColor = true;
      this.GetIpAddress.Click += new System.EventHandler(this.GetIpAddress_Click);
      // 
      // GetDNSAddress
      // 
      this.GetDNSAddress.Location = new System.Drawing.Point(259, 28);
      this.GetDNSAddress.Name = "GetDNSAddress";
      this.GetDNSAddress.Size = new System.Drawing.Size(119, 23);
      this.GetDNSAddress.TabIndex = 1;
      this.GetDNSAddress.Text = "GetLocalDNSAddress";
      this.GetDNSAddress.UseVisualStyleBackColor = true;
      this.GetDNSAddress.Click += new System.EventHandler(this.GetDNSAddress_Click);
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(102, 57);
      this.textBox1.MaxLength = 65535;
      this.textBox1.Multiline = true;
      this.textBox1.Name = "textBox1";
      this.textBox1.ReadOnly = true;
      this.textBox1.Size = new System.Drawing.Size(276, 49);
      this.textBox1.TabIndex = 2;
      // 
      // GetLocalInfo
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
      this.ClientSize = new System.Drawing.Size(464, 232);
      this.Controls.Add(this.textBox1);
      this.Controls.Add(this.GetDNSAddress);
      this.Controls.Add(this.GetIpAddress);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "GetLocalInfo";
      this.Text = "GetLocalInfo";
      this.Load += new System.EventHandler(this.GetLocalInfo_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button GetIpAddress;
    private System.Windows.Forms.Button GetDNSAddress;
    private System.Windows.Forms.TextBox textBox1;
  }
}