﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.NetworkInformation;

namespace EasySystemTools
{
  public partial class GetLocalInfo : Form
  {
    public GetLocalInfo()
    {
      InitializeComponent();
    }

    public void GetIpAddress_Click(object sender, EventArgs e)
    {
        textBox1.Visible = true;
        textBox1.Text = "Local IP Address is :" + "\r\n" + Bussiness.Function.GetIpAddress();
    }

    public void GetDNSAddress_Click(object sender, EventArgs e)
    {
      NetworkInterface[] net = NetworkInterface.GetAllNetworkInterfaces();
      foreach (NetworkInterface ad in net)
      {
        bool judge = (ad.NetworkInterfaceType == NetworkInterfaceType.Ethernet);
        if (judge)
        {
          IPInterfaceProperties ip = ad.GetIPProperties();
          int dnscount = ip.DnsAddresses.Count;
          if (dnscount > 0)
          {
            textBox1.Visible = true;
            textBox1.Text = "Local DNS Address is:"+"\r\n"+ip.DnsAddresses[0].ToString();
          }
        }
      }
    }

    private void GetLocalInfo_Load(object sender, EventArgs e)
    {
      textBox1.Visible = false;
    }

    private void ShowThemAll_Click(object sender, EventArgs e)
    {
        //textBox1.Text = "Local IP Address is :"+"\r\n"+ipad.ToString()+"\r\n"+
    }
  }
}
