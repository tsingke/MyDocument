﻿namespace EasySystemTools
{
  partial class MainF
  {
    /// <summary>
    /// 必需的设计器变量。
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// 清理所有正在使用的资源。
    /// </summary>
    /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows 窗体设计器生成的代码

    /// <summary>
    /// 设计器支持所需的方法 - 不要
    /// 使用代码编辑器修改此方法的内容。
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainF));
        this.menuStrip1 = new System.Windows.Forms.MenuStrip();
        this.systemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.exitXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.functionFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.controlBarCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.commandDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.taskManagerTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.shutDownComputerSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.normalFunctionNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.openNewBrowserOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.getLocalInfoGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.officeSuitsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.helpHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.aboutAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.pictureManagerPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.menuStrip1.SuspendLayout();
        this.SuspendLayout();
        // 
        // menuStrip1
        // 
        this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.systemToolStripMenuItem,
            this.functionFToolStripMenuItem,
            this.normalFunctionNToolStripMenuItem,
            this.helpHToolStripMenuItem});
        this.menuStrip1.Location = new System.Drawing.Point(0, 0);
        this.menuStrip1.Name = "menuStrip1";
        this.menuStrip1.Size = new System.Drawing.Size(472, 25);
        this.menuStrip1.TabIndex = 0;
        this.menuStrip1.Text = "menuStrip1";
        // 
        // systemToolStripMenuItem
        // 
        this.systemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitXToolStripMenuItem});
        this.systemToolStripMenuItem.Name = "systemToolStripMenuItem";
        this.systemToolStripMenuItem.Size = new System.Drawing.Size(76, 21);
        this.systemToolStripMenuItem.Text = "System(&S)";
        // 
        // exitXToolStripMenuItem
        // 
        this.exitXToolStripMenuItem.Name = "exitXToolStripMenuItem";
        this.exitXToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
        this.exitXToolStripMenuItem.Text = "Exit(&X)";
        this.exitXToolStripMenuItem.Click += new System.EventHandler(this.exitXToolStripMenuItem_Click);
        // 
        // functionFToolStripMenuItem
        // 
        this.functionFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.controlBarCToolStripMenuItem,
            this.commandDToolStripMenuItem,
            this.taskManagerTToolStripMenuItem,
            this.shutDownComputerSToolStripMenuItem});
        this.functionFToolStripMenuItem.Name = "functionFToolStripMenuItem";
        this.functionFToolStripMenuItem.Size = new System.Drawing.Size(112, 21);
        this.functionFToolStripMenuItem.Text = "System Tools(&T)";
        // 
        // controlBarCToolStripMenuItem
        // 
        this.controlBarCToolStripMenuItem.Name = "controlBarCToolStripMenuItem";
        this.controlBarCToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
        this.controlBarCToolStripMenuItem.Text = "ControlPanel(&C)";
        this.controlBarCToolStripMenuItem.Click += new System.EventHandler(this.controlBarCToolStripMenuItem_Click);
        // 
        // commandDToolStripMenuItem
        // 
        this.commandDToolStripMenuItem.Name = "commandDToolStripMenuItem";
        this.commandDToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
        this.commandDToolStripMenuItem.Text = "Terminal(&T)";
        this.commandDToolStripMenuItem.Click += new System.EventHandler(this.commandDToolStripMenuItem_Click);
        // 
        // taskManagerTToolStripMenuItem
        // 
        this.taskManagerTToolStripMenuItem.Name = "taskManagerTToolStripMenuItem";
        this.taskManagerTToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
        this.taskManagerTToolStripMenuItem.Text = "TaskManager(&T)";
        this.taskManagerTToolStripMenuItem.Click += new System.EventHandler(this.taskManagerTToolStripMenuItem_Click);
        // 
        // shutDownComputerSToolStripMenuItem
        // 
        this.shutDownComputerSToolStripMenuItem.Name = "shutDownComputerSToolStripMenuItem";
        this.shutDownComputerSToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
        this.shutDownComputerSToolStripMenuItem.Text = "ShutDown Computer(&S)";
        this.shutDownComputerSToolStripMenuItem.Click += new System.EventHandler(this.shutDownComputerSToolStripMenuItem_Click);
        // 
        // normalFunctionNToolStripMenuItem
        // 
        this.normalFunctionNToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openNewBrowserOToolStripMenuItem,
            this.getLocalInfoGToolStripMenuItem,
            this.officeSuitsToolStripMenuItem,
            this.pictureManagerPToolStripMenuItem});
        this.normalFunctionNToolStripMenuItem.Name = "normalFunctionNToolStripMenuItem";
        this.normalFunctionNToolStripMenuItem.Size = new System.Drawing.Size(134, 21);
        this.normalFunctionNToolStripMenuItem.Text = "Normal Function(&N)";
        // 
        // openNewBrowserOToolStripMenuItem
        // 
        this.openNewBrowserOToolStripMenuItem.Name = "openNewBrowserOToolStripMenuItem";
        this.openNewBrowserOToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
        this.openNewBrowserOToolStripMenuItem.Text = "OpenNewBrowser(&O)";
        this.openNewBrowserOToolStripMenuItem.Click += new System.EventHandler(this.openNewBrowserOToolStripMenuItem_Click);
        // 
        // getLocalInfoGToolStripMenuItem
        // 
        this.getLocalInfoGToolStripMenuItem.Name = "getLocalInfoGToolStripMenuItem";
        this.getLocalInfoGToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
        this.getLocalInfoGToolStripMenuItem.Text = "GetLocalInfo(&G)";
        this.getLocalInfoGToolStripMenuItem.Click += new System.EventHandler(this.getlocalinfoGToolStripMenuItem_Click);
        // 
        // officeSuitsToolStripMenuItem
        // 
        this.officeSuitsToolStripMenuItem.Name = "officeSuitsToolStripMenuItem";
        this.officeSuitsToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
        this.officeSuitsToolStripMenuItem.Text = "Office Suits(&O)";
        this.officeSuitsToolStripMenuItem.Click += new System.EventHandler(this.officeSuitsToolStripMenuItem_Click);
        // 
        // helpHToolStripMenuItem
        // 
        this.helpHToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutAToolStripMenuItem});
        this.helpHToolStripMenuItem.Name = "helpHToolStripMenuItem";
        this.helpHToolStripMenuItem.Size = new System.Drawing.Size(64, 21);
        this.helpHToolStripMenuItem.Text = "Help(&H)";
        // 
        // aboutAToolStripMenuItem
        // 
        this.aboutAToolStripMenuItem.Name = "aboutAToolStripMenuItem";
        this.aboutAToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
        this.aboutAToolStripMenuItem.Text = "About(&A)";
        this.aboutAToolStripMenuItem.Click += new System.EventHandler(this.aboutAToolStripMenuItem_Click);
        // 
        // pictureManagerPToolStripMenuItem
        // 
        this.pictureManagerPToolStripMenuItem.Name = "pictureManagerPToolStripMenuItem";
        this.pictureManagerPToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
        this.pictureManagerPToolStripMenuItem.Text = "PictureManager(&P)";
        this.pictureManagerPToolStripMenuItem.Click += new System.EventHandler(this.pictureManagerPToolStripMenuItem_Click);
        // 
        // MainF
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
        this.ClientSize = new System.Drawing.Size(472, 243);
        this.Controls.Add(this.menuStrip1);
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.IsMdiContainer = true;
        this.MainMenuStrip = this.menuStrip1;
        this.Name = "MainF";
        this.Text = "EasySystemTools";
        this.menuStrip1.ResumeLayout(false);
        this.menuStrip1.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem systemToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem exitXToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem functionFToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem controlBarCToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem commandDToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem helpHToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem aboutAToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem taskManagerTToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem normalFunctionNToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem openNewBrowserOToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem getLocalInfoGToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem officeSuitsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem shutDownComputerSToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem pictureManagerPToolStripMenuItem;
  }
}

