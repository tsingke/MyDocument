﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EasySystemTools
{
  public partial class MainF : Form
  {
    public MainF()
    {
      InitializeComponent();
    }

    private void exitXToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Dispose();
      this.Close();
    }

    private void commandDToolStripMenuItem_Click(object sender, EventArgs e)
    {
    string option = "C:\\Windows\\System32\\cmd.exe";
    Bussiness.Function.CreateNewProcess(option);
    }

    private void aboutAToolStripMenuItem_Click(object sender, EventArgs e)
    {
      AboutSoftWare ab = new AboutSoftWare();
      ab.MdiParent = this;
      ab.WindowState = FormWindowState.Maximized;
      ab.Show();
    }

    private void getlocalinfoGToolStripMenuItem_Click(object sender, EventArgs e)
    {
      GetLocalInfo gli = new GetLocalInfo();
      gli.MdiParent = this;
      gli.WindowState = FormWindowState.Maximized;
      gli.Show();
    }

    private void controlBarCToolStripMenuItem_Click(object sender, EventArgs e)
    {
    string option = "C:\\Windows\\System32\\control.exe";
    Bussiness.Function.CreateNewProcess(option);
    }

    private void taskManagerTToolStripMenuItem_Click(object sender, EventArgs e)
    {
        string option = "taskmgr.exe";
        Bussiness.Function.CreateNewProcess(option);
    }

    private void openNewBrowserOToolStripMenuItem_Click(object sender, EventArgs e)
    {
        OpenNewBrowser op = new OpenNewBrowser();
        op.MdiParent = this;
        op.WindowState = FormWindowState.Maximized;
        op.Show();
    }

    private void officeSuitsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      OfficeSuits of = new OfficeSuits();
      of.MdiParent = this;
      of.WindowState = FormWindowState.Maximized;
      of.Show();
    }

    private void shutDownComputerSToolStripMenuItem_Click(object sender, EventArgs e)
    {
      ShutDownComputer st = new ShutDownComputer();
      st.MdiParent = this;
      st.WindowState = FormWindowState.Maximized;
      st.Show();
    }

    private void pictureManagerPToolStripMenuItem_Click(object sender, EventArgs e)
    {
        PictureManager pm = new PictureManager();
        pm.MdiParent = this;
        pm.WindowState = FormWindowState.Maximized;
        pm.Show();
    }
  }
}
