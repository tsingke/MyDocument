﻿namespace EasySystemTools
{
  partial class OfficeSuits
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OfficeSuits));
      this.Word = new System.Windows.Forms.Button();
      this.Excel = new System.Windows.Forms.Button();
      this.PowerPoint = new System.Windows.Forms.Button();
      this.PDF = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // Word
      // 
      this.Word.Location = new System.Drawing.Point(70, 46);
      this.Word.Name = "Word";
      this.Word.Size = new System.Drawing.Size(75, 23);
      this.Word.TabIndex = 0;
      this.Word.Text = "Word";
      this.Word.UseVisualStyleBackColor = true;
      this.Word.Click += new System.EventHandler(this.Word_Click);
      // 
      // Excel
      // 
      this.Excel.Location = new System.Drawing.Point(294, 46);
      this.Excel.Name = "Excel";
      this.Excel.Size = new System.Drawing.Size(75, 23);
      this.Excel.TabIndex = 1;
      this.Excel.Text = "Excel";
      this.Excel.UseVisualStyleBackColor = true;
      this.Excel.Click += new System.EventHandler(this.Excel_Click);
      // 
      // PowerPoint
      // 
      this.PowerPoint.Location = new System.Drawing.Point(70, 150);
      this.PowerPoint.Name = "PowerPoint";
      this.PowerPoint.Size = new System.Drawing.Size(75, 23);
      this.PowerPoint.TabIndex = 2;
      this.PowerPoint.Text = "PowerPoint";
      this.PowerPoint.UseVisualStyleBackColor = true;
      this.PowerPoint.Click += new System.EventHandler(this.PowerPoint_Click);
      // 
      // PDF
      // 
      this.PDF.Location = new System.Drawing.Point(294, 149);
      this.PDF.Name = "PDF";
      this.PDF.Size = new System.Drawing.Size(75, 23);
      this.PDF.TabIndex = 3;
      this.PDF.Text = "PDF";
      this.PDF.UseVisualStyleBackColor = true;
      this.PDF.Click += new System.EventHandler(this.PDF_Click);
      // 
      // OfficeSuits
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
      this.ClientSize = new System.Drawing.Size(472, 243);
      this.Controls.Add(this.PDF);
      this.Controls.Add(this.PowerPoint);
      this.Controls.Add(this.Excel);
      this.Controls.Add(this.Word);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "OfficeSuits";
      this.Text = "OfficeSuits";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button Word;
    private System.Windows.Forms.Button Excel;
    private System.Windows.Forms.Button PowerPoint;
    private System.Windows.Forms.Button PDF;
  }
}