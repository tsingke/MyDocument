﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EasySystemTools
{
  public partial class OfficeSuits : Form
  {
    public OfficeSuits()
    {
      InitializeComponent();
    }

    private void Word_Click(object sender, EventArgs e)
    {
      string option = "D:\\software\\WPS Office\\9.1.0.4249\\office6\\wps.exe";
      Bussiness.Function.CreateNewProcess(option);
    }

    private void Excel_Click(object sender, EventArgs e)
    {
      string option = "D:\\software\\WPS Office\\9.1.0.4249\\office6\\et.exe";
      Bussiness.Function.CreateNewProcess(option);
    }

    private void PowerPoint_Click(object sender, EventArgs e)
    {
        string option = "D:\\software\\WPS Office\\9.1.0.4249\\office6\\wpp.exe";
      Bussiness.Function.CreateNewProcess(option);
    }
    private void PDF_Click(object sender, EventArgs e)
    {
      string option = "acrord32.exe";
      Bussiness.Function.CreateNewProcess(option);
    }
  }
}
