﻿namespace EasySystemTools
{
    partial class OpenNewBrowser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OpenNewBrowser));
      this.Chrome = new System.Windows.Forms.Button();
      this.IE = new System.Windows.Forms.Button();
      this.FireFox = new System.Windows.Forms.Button();
      this.Sougou = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.KSBrowser = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // Chrome
      // 
      this.Chrome.Location = new System.Drawing.Point(171, 133);
      this.Chrome.Name = "Chrome";
      this.Chrome.Size = new System.Drawing.Size(75, 23);
      this.Chrome.TabIndex = 0;
      this.Chrome.Text = "Chrome";
      this.Chrome.UseVisualStyleBackColor = true;
      this.Chrome.Click += new System.EventHandler(this.Chrome_Click);
      // 
      // IE
      // 
      this.IE.Location = new System.Drawing.Point(255, 96);
      this.IE.Name = "IE";
      this.IE.Size = new System.Drawing.Size(75, 23);
      this.IE.TabIndex = 1;
      this.IE.Text = "IE";
      this.IE.UseVisualStyleBackColor = true;
      this.IE.Click += new System.EventHandler(this.IE_Click);
      // 
      // FireFox
      // 
      this.FireFox.Location = new System.Drawing.Point(88, 172);
      this.FireFox.Name = "FireFox";
      this.FireFox.Size = new System.Drawing.Size(75, 23);
      this.FireFox.TabIndex = 2;
      this.FireFox.Text = "FireFox";
      this.FireFox.UseVisualStyleBackColor = true;
      this.FireFox.Click += new System.EventHandler(this.FireFox_Click);
      // 
      // Sougou
      // 
      this.Sougou.Location = new System.Drawing.Point(255, 172);
      this.Sougou.Name = "Sougou";
      this.Sougou.Size = new System.Drawing.Size(75, 23);
      this.Sougou.TabIndex = 3;
      this.Sougou.Text = "Sougou";
      this.Sougou.UseVisualStyleBackColor = true;
      this.Sougou.Click += new System.EventHandler(this.Sougou_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(88, 25);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(113, 12);
      this.label1.TabIndex = 4;
      this.label1.Text = "Input a internet address";
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(90, 51);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(240, 22);
      this.textBox1.TabIndex = 5;
      // 
      // KSBrowser
      // 
      this.KSBrowser.Location = new System.Drawing.Point(88, 96);
      this.KSBrowser.Name = "KSBrowser";
      this.KSBrowser.Size = new System.Drawing.Size(75, 23);
      this.KSBrowser.TabIndex = 6;
      this.KSBrowser.Text = "KSBrowser";
      this.KSBrowser.UseVisualStyleBackColor = true;
      this.KSBrowser.Click += new System.EventHandler(this.KSBrowser_Click);
      // 
      // OpenNewBrowser
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
      this.ClientSize = new System.Drawing.Size(464, 232);
      this.Controls.Add(this.KSBrowser);
      this.Controls.Add(this.textBox1);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.Sougou);
      this.Controls.Add(this.FireFox);
      this.Controls.Add(this.IE);
      this.Controls.Add(this.Chrome);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "OpenNewBrowser";
      this.Text = "OpenNewBrowser";
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Chrome;
        private System.Windows.Forms.Button IE;
        private System.Windows.Forms.Button FireFox;
        private System.Windows.Forms.Button Sougou;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button KSBrowser;
    }
}