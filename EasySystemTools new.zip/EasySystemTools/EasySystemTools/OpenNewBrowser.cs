﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EasySystemTools
{
  public partial class OpenNewBrowser : Form
  {
    public OpenNewBrowser()
    {
      InitializeComponent();
    }

    private void KSBrowser_Click(object sender, EventArgs e)
    {
      string option = "D:\\software\\liebao\\LBBrowser\\liebao.exe";
      string address = textBox1.Text;
      Bussiness.Function.CreateBrowserProcess(option, address);
    }

    private void IE_Click(object sender, EventArgs e)
    {
      string option = "iexplore.exe";
      string address = textBox1.Text;
      Bussiness.Function.CreateBrowserProcess(option, address);
    }

    private void Chrome_Click(object sender, EventArgs e)
    {
      string option = "chrome.exe";
      string address = textBox1.Text;
      Bussiness.Function.CreateBrowserProcess(option, address);
    }

    private void FireFox_Click(object sender, EventArgs e)
    {
      string option = "D:\\software\\firefox\\firefox.exe";
      string address = textBox1.Text;
      Bussiness.Function.CreateBrowserProcess(option, address);
    }

    private void Sougou_Click(object sender, EventArgs e)
    {
      string option = "D:\\software\\SogouExplorer\\SogouExplorer.exe";
      string address = textBox1.Text;
      Bussiness.Function.CreateBrowserProcess(option, address);
    }
  }
}
