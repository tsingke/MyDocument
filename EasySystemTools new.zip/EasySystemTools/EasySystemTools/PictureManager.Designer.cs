﻿namespace EasySystemTools
{
    partial class PictureManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PictureManager));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开图片OToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.savePictureSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setAsDesktopSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPicturePToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图片滤镜效果ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.纹理滤镜ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.浮雕滤镜ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.积木滤镜ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.雾化滤镜ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.底片滤镜ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图片动画效果ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.水平遮罩ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.垂直遮罩ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.上下拉伸ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.左右拉伸ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.两边拉伸ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.水平百叶窗ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.垂直百叶窗ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.翻转动画ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.扩展动画ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.马赛克动画ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图片的调整ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图片的水印效果ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图片的幻灯片预览ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileFToolStripMenuItem,
            this.图片滤镜效果ToolStripMenuItem,
            this.图片动画效果ToolStripMenuItem,
            this.图片的调整ToolStripMenuItem,
            this.图片的水印效果ToolStripMenuItem,
            this.图片的幻灯片预览ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(584, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileFToolStripMenuItem
            // 
            this.fileFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开图片OToolStripMenuItem,
            this.savePictureSToolStripMenuItem,
            this.setAsDesktopSToolStripMenuItem,
            this.printPicturePToolStripMenuItem,
            this.exitEToolStripMenuItem});
            this.fileFToolStripMenuItem.Name = "fileFToolStripMenuItem";
            this.fileFToolStripMenuItem.Size = new System.Drawing.Size(53, 21);
            this.fileFToolStripMenuItem.Text = "File(&F)";
            // 
            // 打开图片OToolStripMenuItem
            // 
            this.打开图片OToolStripMenuItem.Name = "打开图片OToolStripMenuItem";
            this.打开图片OToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.打开图片OToolStripMenuItem.Text = "打开图片(&O)";
            this.打开图片OToolStripMenuItem.Click += new System.EventHandler(this.打开图片OToolStripMenuItem_Click);
            // 
            // savePictureSToolStripMenuItem
            // 
            this.savePictureSToolStripMenuItem.Name = "savePictureSToolStripMenuItem";
            this.savePictureSToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.savePictureSToolStripMenuItem.Text = "保存图片(&S)";
            this.savePictureSToolStripMenuItem.Click += new System.EventHandler(this.savePictureSToolStripMenuItem_Click);
            // 
            // setAsDesktopSToolStripMenuItem
            // 
            this.setAsDesktopSToolStripMenuItem.Name = "setAsDesktopSToolStripMenuItem";
            this.setAsDesktopSToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.setAsDesktopSToolStripMenuItem.Text = "设置为桌面背景(&S)";
            // 
            // printPicturePToolStripMenuItem
            // 
            this.printPicturePToolStripMenuItem.Name = "printPicturePToolStripMenuItem";
            this.printPicturePToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.printPicturePToolStripMenuItem.Text = "打印图片(&P)";
            // 
            // exitEToolStripMenuItem
            // 
            this.exitEToolStripMenuItem.Name = "exitEToolStripMenuItem";
            this.exitEToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.exitEToolStripMenuItem.Text = "退出(&E)";
            this.exitEToolStripMenuItem.Click += new System.EventHandler(this.exitEToolStripMenuItem_Click);
            // 
            // 图片滤镜效果ToolStripMenuItem
            // 
            this.图片滤镜效果ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.纹理滤镜ToolStripMenuItem,
            this.浮雕滤镜ToolStripMenuItem,
            this.积木滤镜ToolStripMenuItem,
            this.雾化滤镜ToolStripMenuItem,
            this.底片滤镜ToolStripMenuItem});
            this.图片滤镜效果ToolStripMenuItem.Name = "图片滤镜效果ToolStripMenuItem";
            this.图片滤镜效果ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.图片滤镜效果ToolStripMenuItem.Text = "图片滤镜效果";
            // 
            // 纹理滤镜ToolStripMenuItem
            // 
            this.纹理滤镜ToolStripMenuItem.Name = "纹理滤镜ToolStripMenuItem";
            this.纹理滤镜ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.纹理滤镜ToolStripMenuItem.Text = "纹理滤镜";
            // 
            // 浮雕滤镜ToolStripMenuItem
            // 
            this.浮雕滤镜ToolStripMenuItem.Name = "浮雕滤镜ToolStripMenuItem";
            this.浮雕滤镜ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.浮雕滤镜ToolStripMenuItem.Text = "浮雕滤镜";
            // 
            // 积木滤镜ToolStripMenuItem
            // 
            this.积木滤镜ToolStripMenuItem.Name = "积木滤镜ToolStripMenuItem";
            this.积木滤镜ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.积木滤镜ToolStripMenuItem.Text = "积木滤镜";
            // 
            // 雾化滤镜ToolStripMenuItem
            // 
            this.雾化滤镜ToolStripMenuItem.Name = "雾化滤镜ToolStripMenuItem";
            this.雾化滤镜ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.雾化滤镜ToolStripMenuItem.Text = "雾化滤镜";
            // 
            // 底片滤镜ToolStripMenuItem
            // 
            this.底片滤镜ToolStripMenuItem.Name = "底片滤镜ToolStripMenuItem";
            this.底片滤镜ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.底片滤镜ToolStripMenuItem.Text = "底片滤镜";
            // 
            // 图片动画效果ToolStripMenuItem
            // 
            this.图片动画效果ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.水平遮罩ToolStripMenuItem,
            this.垂直遮罩ToolStripMenuItem,
            this.上下拉伸ToolStripMenuItem,
            this.左右拉伸ToolStripMenuItem,
            this.两边拉伸ToolStripMenuItem,
            this.水平百叶窗ToolStripMenuItem,
            this.垂直百叶窗ToolStripMenuItem,
            this.翻转动画ToolStripMenuItem,
            this.扩展动画ToolStripMenuItem,
            this.马赛克动画ToolStripMenuItem});
            this.图片动画效果ToolStripMenuItem.Name = "图片动画效果ToolStripMenuItem";
            this.图片动画效果ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.图片动画效果ToolStripMenuItem.Text = "图片动画效果";
            // 
            // 水平遮罩ToolStripMenuItem
            // 
            this.水平遮罩ToolStripMenuItem.Name = "水平遮罩ToolStripMenuItem";
            this.水平遮罩ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.水平遮罩ToolStripMenuItem.Text = "水平遮罩";
            // 
            // 垂直遮罩ToolStripMenuItem
            // 
            this.垂直遮罩ToolStripMenuItem.Name = "垂直遮罩ToolStripMenuItem";
            this.垂直遮罩ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.垂直遮罩ToolStripMenuItem.Text = "垂直遮罩";
            // 
            // 上下拉伸ToolStripMenuItem
            // 
            this.上下拉伸ToolStripMenuItem.Name = "上下拉伸ToolStripMenuItem";
            this.上下拉伸ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.上下拉伸ToolStripMenuItem.Text = "上下拉伸";
            // 
            // 左右拉伸ToolStripMenuItem
            // 
            this.左右拉伸ToolStripMenuItem.Name = "左右拉伸ToolStripMenuItem";
            this.左右拉伸ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.左右拉伸ToolStripMenuItem.Text = "左右拉伸";
            // 
            // 两边拉伸ToolStripMenuItem
            // 
            this.两边拉伸ToolStripMenuItem.Name = "两边拉伸ToolStripMenuItem";
            this.两边拉伸ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.两边拉伸ToolStripMenuItem.Text = "两边拉伸";
            // 
            // 水平百叶窗ToolStripMenuItem
            // 
            this.水平百叶窗ToolStripMenuItem.Name = "水平百叶窗ToolStripMenuItem";
            this.水平百叶窗ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.水平百叶窗ToolStripMenuItem.Text = "水平百叶窗";
            // 
            // 垂直百叶窗ToolStripMenuItem
            // 
            this.垂直百叶窗ToolStripMenuItem.Name = "垂直百叶窗ToolStripMenuItem";
            this.垂直百叶窗ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.垂直百叶窗ToolStripMenuItem.Text = "垂直百叶窗";
            // 
            // 翻转动画ToolStripMenuItem
            // 
            this.翻转动画ToolStripMenuItem.Name = "翻转动画ToolStripMenuItem";
            this.翻转动画ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.翻转动画ToolStripMenuItem.Text = "翻转动画";
            // 
            // 扩展动画ToolStripMenuItem
            // 
            this.扩展动画ToolStripMenuItem.Name = "扩展动画ToolStripMenuItem";
            this.扩展动画ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.扩展动画ToolStripMenuItem.Text = "扩展动画";
            // 
            // 马赛克动画ToolStripMenuItem
            // 
            this.马赛克动画ToolStripMenuItem.Name = "马赛克动画ToolStripMenuItem";
            this.马赛克动画ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.马赛克动画ToolStripMenuItem.Text = "马赛克动画";
            // 
            // 图片的调整ToolStripMenuItem
            // 
            this.图片的调整ToolStripMenuItem.Name = "图片的调整ToolStripMenuItem";
            this.图片的调整ToolStripMenuItem.Size = new System.Drawing.Size(80, 21);
            this.图片的调整ToolStripMenuItem.Text = "图片的调整";
            // 
            // 图片的水印效果ToolStripMenuItem
            // 
            this.图片的水印效果ToolStripMenuItem.Name = "图片的水印效果ToolStripMenuItem";
            this.图片的水印效果ToolStripMenuItem.Size = new System.Drawing.Size(104, 21);
            this.图片的水印效果ToolStripMenuItem.Text = "图片的水印效果";
            // 
            // 图片的幻灯片预览ToolStripMenuItem
            // 
            this.图片的幻灯片预览ToolStripMenuItem.Name = "图片的幻灯片预览ToolStripMenuItem";
            this.图片的幻灯片预览ToolStripMenuItem.Size = new System.Drawing.Size(116, 21);
            this.图片的幻灯片预览ToolStripMenuItem.Text = "图片的幻灯片预览";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 340);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(584, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(0, 17);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(584, 315);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // PictureManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 362);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "PictureManager";
            this.Text = "PictureManager";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开图片OToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem savePictureSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setAsDesktopSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPicturePToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图片滤镜效果ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 纹理滤镜ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 浮雕滤镜ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 积木滤镜ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 雾化滤镜ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 底片滤镜ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图片动画效果ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 水平遮罩ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 垂直遮罩ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 上下拉伸ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 左右拉伸ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 两边拉伸ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 水平百叶窗ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 垂直百叶窗ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 翻转动画ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 扩展动画ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 马赛克动画ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图片的调整ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图片的水印效果ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图片的幻灯片预览ToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}