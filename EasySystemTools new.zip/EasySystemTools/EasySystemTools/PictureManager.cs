﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace EasySystemTools
{
    public partial class PictureManager : Form
    {
        public PictureManager()
        {
            InitializeComponent();
        }
        public Bitmap image1;
        public string FPath;
        public string PictureWidth;
        public string PictureHeight;

        private void 打开图片OToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "*.jpg,*.jpeg,*.bmp,*.gif,*.ico,*.png,*.tif,*.wmf|*.jpg;*.jpeg;*.bmp;*.gif;*.ico;*.png;*.tif;*.wmf";
            openFileDialog1.ShowDialog();
            FPath = openFileDialog1.FileName;
            pictureBox1.Image = Image.FromFile(FPath);
            image1 = new Bitmap(FPath);
            PictureWidth = image1.Width.ToString();
            PictureHeight = image1.Height.ToString();
            toolStripStatusLabel2.Text = "图片名为:"+ FPath +"宽度:" + PictureWidth +"高度 "+PictureHeight;
        }

        private void exitEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dispose();
            this.Close();
        }

        private void savePictureSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                saveFileDialog1.Filter = "BMP|*.bmp|JPEG|*.jpeg|GIF|*.gif|PNG|*.png";
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    string PicPath = saveFileDialog1.FileName;
                    string PicType = PicPath.Substring(PicPath.LastIndexOf(".") + 1,(PicPath.Length-PicPath.LastIndexOf(".") - 1));
                    switch (PicType)
                    {
                        case "bmp":
                            Bitmap bt = new Bitmap(FPath);
                            bt.Save(PicPath, ImageFormat.Bmp);break;
                        case "jpeg":
                            Bitmap btjpeg = new Bitmap(FPath);
                            btjpeg.Save(PicPath, ImageFormat.Jpeg);break;
                        case "gif":
                            Bitmap btgif = new Bitmap(FPath);
                            btgif.Save(PicPath, ImageFormat.Gif);break;
                        case "png":
                            Bitmap btpng = new Bitmap(FPath);
                            btpng.Save(PicPath, ImageFormat.Png);break;

                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"提示",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }

    }
}
