﻿namespace EasySystemTools
{
  partial class ShutDownComputer
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShutDownComputer));
      this.ShutDown = new System.Windows.Forms.Button();
      this.ReStart = new System.Windows.Forms.Button();
      this.DelayTime = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // ShutDown
      // 
      this.ShutDown.Location = new System.Drawing.Point(99, 147);
      this.ShutDown.Name = "ShutDown";
      this.ShutDown.Size = new System.Drawing.Size(75, 23);
      this.ShutDown.TabIndex = 0;
      this.ShutDown.Text = "ShutDown";
      this.ShutDown.UseVisualStyleBackColor = true;
      this.ShutDown.Click += new System.EventHandler(this.ShutDown_Click);
      // 
      // ReStart
      // 
      this.ReStart.Location = new System.Drawing.Point(286, 146);
      this.ReStart.Name = "ReStart";
      this.ReStart.Size = new System.Drawing.Size(75, 23);
      this.ReStart.TabIndex = 1;
      this.ReStart.Text = "ReStart";
      this.ReStart.UseVisualStyleBackColor = true;
      this.ReStart.Click += new System.EventHandler(this.ReStart_Click);
      // 
      // DelayTime
      // 
      this.DelayTime.Location = new System.Drawing.Point(202, 53);
      this.DelayTime.Name = "DelayTime";
      this.DelayTime.Size = new System.Drawing.Size(100, 22);
      this.DelayTime.TabIndex = 2;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(97, 63);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(99, 12);
      this.label1.TabIndex = 3;
      this.label1.Text = "Input Delay Time(s)";
      // 
      // ShutDownComputer
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(472, 243);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.DelayTime);
      this.Controls.Add(this.ReStart);
      this.Controls.Add(this.ShutDown);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "ShutDownComputer";
      this.Text = "ShutDownComputer";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button ShutDown;
    private System.Windows.Forms.Button ReStart;
    private System.Windows.Forms.TextBox DelayTime;
    private System.Windows.Forms.Label label1;
  }
}