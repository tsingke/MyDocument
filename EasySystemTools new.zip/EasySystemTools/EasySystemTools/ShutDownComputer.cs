﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EasySystemTools
{
  public partial class ShutDownComputer : Form
  {
    public ShutDownComputer()
    {
      InitializeComponent();
    }

    private void ShutDown_Click(object sender, EventArgs e)
    {
     var get = DelayTime.Text;
     if(!String.IsNullOrEmpty(get))
     {
     var time = Convert.ToInt32(get);
     string shut = "shutdown /s /t ";
     string shutdown = shut+time.ToString();
     if(time>=0)
     {
     System.Diagnostics.Process process = new System.Diagnostics.Process();
     process.StartInfo.FileName = "cmd.exe";
     process.StartInfo.UseShellExecute = false;
     process.StartInfo.RedirectStandardInput = true;
     process.StartInfo.RedirectStandardOutput = true;
     process.StartInfo.RedirectStandardError = true;
     process.StartInfo.CreateNoWindow = true;
     process.Start();
     process.StandardInput.WriteLine(shutdown);
    }
    else MessageBox.Show("error:input time must be bigger than 0 or equal to 0");
    }
    else MessageBox.Show("error:no input");
    }

    private void ReStart_Click(object sender, EventArgs e)
    {
      var get = DelayTime.Text;
      if (!String.IsNullOrEmpty(get))
      {
        var time = Convert.ToInt32(get);
        string shut = "shutdown /r /t ";
        string shutdown = shut + time.ToString();
        if (time >= 0)
        {
          System.Diagnostics.Process process = new System.Diagnostics.Process();
          process.StartInfo.FileName = "cmd.exe";
          process.StartInfo.UseShellExecute = false;
          process.StartInfo.RedirectStandardInput = true;
          process.StartInfo.RedirectStandardOutput = true;
          process.StartInfo.RedirectStandardError = true;
          process.StartInfo.CreateNoWindow = true;
          process.Start();
          process.StandardInput.WriteLine(shutdown);
        }
        else MessageBox.Show("error:input time must be bigger than 0 or equal to 0");
      }
      else MessageBox.Show("error:no input");
    }
  }
}
