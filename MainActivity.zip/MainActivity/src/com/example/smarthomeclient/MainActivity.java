package com.example.smarthomeclient;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.ToggleButton;//

public class MainActivity extends Activity {
	//mainactivity
	private Button btn_connect;
	private Button btn_gas;
	private Button btn_light;
	private Button btn_temp;
	private Button btn_exit;
	private ToggleButton led1;
	private ToggleButton led2;
	private ToggleButton led3;
	private ToggleButton led4;
	//temp
	private EditText temp_et1;
	private EditText temp_et2;
	private EditText temp_et3;
	private EditText temp_et4;
	private Button temp_back;
	//light
	private EditText light_et1;
	private EditText light_et2;
	private EditText light_et3;
	private EditText light_et4;
	//gas
	private EditText gas_et1;
	private EditText gas_et2;
	private EditText gas_et3;
	private EditText gas_et4;
	private RadioButton gas_rb1;
	private RadioButton gas_rb2;
	private RadioButton gas_rb3;
	private RadioButton gas_rb4;
	
	private String TempStr[];//用于存放温度数值
	private String LightLevelStr[];//用于存放光强数值
	private String GasStr[];//用于存放瓦斯数值
	private String AlarmFlag[];//用于报警标识
	private String LedFlag[];//用于灯状态标识
	private TextView mTextShow;
	Socket socket=null;
	
	private final int TIMER_INVALIDATE = 1001;
	private int dlgIndex = 0;
	private int cnt = 0;
	private Double testValue = new Double(75.123);
	
	private Timer timer;
	private TimerTask task;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btn_connect=(Button)findViewById(R.id.btn_connect);
		btn_gas=(Button)findViewById(R.id.btn_gas);
		btn_light=(Button)findViewById(R.id.btn_light);
		btn_temp=(Button)findViewById(R.id.btn_temp);
		btn_exit=(Button)findViewById(R.id.btn_exit);
		btn_exit.setOnClickListener(new exitclick());
		btn_connect.setOnClickListener(new connectclick());
		btn_gas.setOnClickListener(new gasclick());
		btn_temp.setOnClickListener(new tempclick());
		btn_light.setOnClickListener(new lightclick());
		led1=(ToggleButton)findViewById(R.id.led1);
		led2=(ToggleButton)findViewById(R.id.led2);
		led3=(ToggleButton)findViewById(R.id.led3);
		led4=(ToggleButton)findViewById(R.id.led4);
		temp_et1=(EditText)findViewById(R.id.temp_et1);
		temp_et2=(EditText)findViewById(R.id.temp_et2);
		temp_et3=(EditText)findViewById(R.id.temp_et3);
		temp_et4=(EditText)findViewById(R.id.temp_et4);
		light_et1=(EditText)findViewById(R.id.light_et1);
		light_et2=(EditText)findViewById(R.id.light_et2);
		light_et3=(EditText)findViewById(R.id.light_et3);
		light_et4=(EditText)findViewById(R.id.light_et4);
		gas_et1=(EditText)findViewById(R.id.gas_et1);
		gas_et2=(EditText)findViewById(R.id.gas_et2);
		gas_et3=(EditText)findViewById(R.id.gas_et3);
		gas_et4=(EditText)findViewById(R.id.gas_et4);
		gas_rb1=(RadioButton)findViewById(R.id.gas_rb1);
		gas_rb2=(RadioButton)findViewById(R.id.gas_rb2);
		gas_rb3=(RadioButton)findViewById(R.id.gas_rb3);
		gas_rb4=(RadioButton)findViewById(R.id.gas_rb4);
	}
	public static String bytes2HexString(byte[] b) 
    {
    	String ret = "";
    	for (int i = 0; i < b.length; i++) 
    	{
	    	String hex = Integer.toHexString(b[i] & 0xFF);
	    	if (hex.length() == 1) 
	    	{
	    		hex = '0' + hex;
	    	}
	    	ret += hex.toUpperCase();
    	}
    	return ret;
    }
	public void receive(){
    	new Thread(){
			public void run(){
				try{
					
					while(!socket.isClosed()){//假如socket是打开的
						
						InputStream is = socket.getInputStream(); 

						byte data[] = new byte[512];
						int n = is.read(data);
						if(n > 0){						
							String val = new String(data);							
							//解析数据	
							switch(val.charAt(1))
							{
							case 'T':
								TempStr = val.split(",");
								break;
							case 'L':
								LightLevelStr = val.split(",");
								break;
							case 'G':
								GasStr = val.split(",");
								break;
							case 'A'://报警
								AlarmFlag = val.split(",");
								break;
							case 'D'://灯状态
								LedFlag = val.split(",");
								break;
							
							}
							
							
							//Log.d("TCP","receive mStrShow="+mStrShow);
							//Log.d("TCP","receive mStrShow=");
							Message message = new Message();// 生成消息，并赋予ID值
							message.what = TIMER_INVALIDATE;
							myHandler.sendMessage(message);// 投递消息
						}
						
						sleep(300);
					}
				}
				catch(Exception e){

				}
			}
		}.start();
    }
	private void close(){
    	try {
    		Log.d("TCP","socket close");
    		if(socket != null)
    		{
    			socket.close();    			
    		}
	    	finish();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			 Log.e("TCP", "S: Error", e); 
		} 
    }
        
    private void MySend(String message){
    	try{		    	    
	    	PrintWriter out = new PrintWriter( new BufferedWriter( new OutputStreamWriter(socket.getOutputStream())),true); 
		    out.println(message);
		    out.flush();
	    
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
    
    
    Handler myHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case TIMER_INVALIDATE://查询灯状态
				if(dlgIndex == 0)
				{
					if(LedFlag[1].charAt(0) == 0x30)
					{
						led1.setChecked(false);
					}
					else if(LedFlag[1].charAt(0) == 0x31)
					{
						led1.setChecked(true);
					}
					
					if(LedFlag[2].charAt(0) == 0x30)
					{
						led2.setChecked(false);
					}
					else if(LedFlag[2].charAt(0) == 0x31)
					{
						led2.setChecked(true);
					}
					
					if(LedFlag[3].charAt(0) == 0x30)
					{
						led3.setChecked(false);
					}
					else if(LedFlag[3].charAt(0) == 0x31)
					{
						led3.setChecked(true);
					}
					
					if(LedFlag[4].charAt(0) == 0x30)
					{
						led4.setChecked(false);
					}
					else if(LedFlag[4].charAt(0) == 0x31)
					{
						led4.setChecked(true);
					}
				}
				else if(dlgIndex == 1) //温度监控界面
				{
					temp_et1.setText(TempStr[1]);
					temp_et2.setText(TempStr[2]);
					temp_et3.setText(TempStr[3]);
					temp_et4.setText(TempStr[4]);					
				}
				else if(dlgIndex == 2) //光强监控界面
				{
					light_et1.setText(LightLevelStr[1]);
					light_et2.setText(LightLevelStr[2]);
					light_et3.setText(LightLevelStr[3]);
					light_et4.setText(LightLevelStr[4]);					
				}
				else if(dlgIndex == 3) //瓦斯监控界面
				{
					if(cnt == 1)
					{
						gas_et1.setText(GasStr[1]);
						gas_et2.setText(GasStr[2]);
						gas_et3.setText(GasStr[3]);
						gas_et4.setText(GasStr[4]);	
					}
					else if(cnt == 0)
					{
						if(AlarmFlag[1].charAt(0) == 0x30)
						{
							gas_rb1.setChecked(false);
						}
						else if(AlarmFlag[1].charAt(0) == 0x31)
						{
							gas_rb1.setChecked(true);
						}
						
						if(AlarmFlag[2].charAt(0) == 0x30)
						{
							gas_rb2.setChecked(false);
						}
						else if(AlarmFlag[2].charAt(0) == 0x31)
						{
							gas_rb2.setChecked(true);
						}
						
						if(AlarmFlag[3].charAt(0) == 0x30)
						{
							gas_rb3.setChecked(false);
						}
						else if(AlarmFlag[3].charAt(0) == 0x31)
						{
							gas_rb3.setChecked(true);
						}
						
						if(AlarmFlag[4].charAt(0) == 0x30)
						{
							gas_rb4.setChecked(false);
						}
						else if(AlarmFlag[4].charAt(0) == 0x31)
						{
							gas_rb4.setChecked(true);
						}
						
					}			
					
					
				}
				
				break;
			case 1://定时向server发送请求事件
				if(dlgIndex == 0)
				{
					MySend("DDDDD");  //主界面
				}
				else if(dlgIndex == 1)//温度监控界面
				{
					MySend("TTTTT");
				}
				else if(dlgIndex == 2)//光强监控界面
				{
					MySend("LLLLL");
				}
				else if(dlgIndex == 3)//瓦斯监控界面
				{
					if(cnt == 0)
					{
						cnt = 1;
						MySend("GGGGG");
					}
					else if(cnt == 1)
					{
						cnt = 0;
						MySend("AAAAA");
					}		
					
					
				}
				break;
			}
			super.handleMessage(msg);
		}
	};
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		menu.add(0, 1, 1, R.string.about);
		menu.add(0, 2, 2, R.string.exit);
		return true;
	}

		
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		if(item.getItemId()==1){
			new aboutclick();
		}
		else if(item.getItemId()==2){
			finish();
			System.exit(0);
		}
		return true;
	
	}
	public class exitclick implements OnClickListener{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			//finish();
			System.exit(0);
		}
		
	}
	public class connectclick implements OnClickListener{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent connect=new Intent();
			connect.setClass(MainActivity.this, connect.class);
			MainActivity.this.startActivity(connect);
			//MainActivity.this.finish();	
		}
	}
	public class gasclick implements OnClickListener{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent gas=new Intent();
			gas.setClass(MainActivity.this, gas.class);
			MainActivity.this.startActivity(gas);
			
			//MainActivity.this.finish();
		}
	}
	public class tempclick implements OnClickListener{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent temp=new Intent();
			temp.setClass(MainActivity.this, temp.class);
			MainActivity.this.startActivity(temp);
			
			//MainActivity.this.finish();
		}
	}
	public class lightclick implements OnClickListener{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent light=new Intent();
			light.setClass(MainActivity.this, light.class);
			MainActivity.this.startActivity(light);
			
			//MainActivity.this.finish();
		}
	}
	public class aboutclick implements OnItemClickListener{

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			Intent about=new Intent();
			about.setClass(MainActivity.this, about.class);
			MainActivity.this.startActivity(about);
			//MainActivity.this.finish();
		}
		
	}
}
	
	
	