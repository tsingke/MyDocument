package com.example.smarthomeclient;

import java.net.InetAddress;
import java.net.Socket;

import android.app.Activity;
import android.content.Intent;
import android.opengl.Visibility;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class connect extends Activity{
	
	    //
		private EditText edtext_connect;
		private Button ok;
		private Button cancel;
		public String SOCKET_IP;
		public String input;
		private int SOCKET_PORT=51706;
		Socket socket=null;
		
		
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			super.onCreate(savedInstanceState);
			setContentView(R.layout.connect);
			ok=(Button)findViewById(R.id.ok);
			ok.setOnClickListener(new okclick());
			cancel=(Button)findViewById(R.id.cancel);
			cancel.setOnClickListener(new cancelclick());
		}
			public void connect(){
				SOCKET_IP=input;
	    	try { 
	    		InetAddress serverAddr = InetAddress.getByName(SOCKET_IP);//TCPServer.SERVERIP 
	        	Log.d("TCP", "C: Connecting..."); 
	        	socket = new Socket(serverAddr, SOCKET_PORT);       	
	        	
	 //   	    PrintWriter out = new PrintWriter( new BufferedWriter( new OutputStreamWriter(socket.getOutputStream())),true); 
	 //   	    out.println(message);
	 //   	    out.flush();
	    	   //receive();
	        	Toast.makeText(connect.this, "连接成功", Toast.LENGTH_LONG).show();
	        	Intent jump=new Intent();
	        	jump.setClass(connect.this, MainActivity.class);
	        	connect.this.startActivity(jump);
	    	} catch(Exception e) { 
	    		Toast.makeText(connect.this, "orz...连接失败，请检查网络连接后重试。",Toast.LENGTH_LONG).show();
	    	    Log.e("TCP", "S: Error", e); 
	    	} finally { 
	    	    
	    	} 
	    }
			
			
		public class cancelclick implements OnClickListener{

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent cancel=new Intent();
				cancel.setClass(connect.this, MainActivity.class);
				cancel.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				connect.this.startActivity(cancel);
				connect.this.finish();
				finishActivity(0);
			}
			
		}
		public class okclick implements OnClickListener{

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				input=edtext_connect.getText().toString();
				//isIpAddress(input);
				connect();
				Toast.makeText(connect.this, "连接中...",Toast.LENGTH_LONG).show();
			}
	}
		/*public boolean isIpAddress(String input) {
			int start = 0; 
			int end = input.indexOf('.'); 
			int numBlocks = 0; 
			while (start < input.length()) { 
			if (end == -1) { 
			end = input.length(); 
			} 
			try { 
			int block = Integer.parseInt(input.substring(start, end)); 
			if ((block > 255) || (block < 0)) { 
			Toast.makeText(connect.this, "输入的ip地址有误，请重新输入。", Toast.LENGTH_LONG).show();
			}
			}
			catch (NumberFormatException e) { 
			return false; 
			} 
			numBlocks++; 
			start = end + 1; 
			end = input.indexOf('.', start); 
			} 
			return numBlocks == 4; 
			} */
}